import pandas as pd
import numpy as np
from datetime import datetime, timedelta

# Define appliance power consumption (in watts)
APPLIANCE_POWER = {
    'TV': 150,  # LED TV average
    'AC': 1500,  # 1.5 ton AC
    'Washing Machine': 750,  # Front load washing machine
    'Refrigerator': 200,  # Double door fridge
    'Microwave': 800,  # Standard microwave
    'Light Bulbs': 40,  # LED lights total
    'Fan': 75,  # Ceiling fan
    'Water Heater': 2000,  # Geyser
    'Iron': 1000,  # Clothing iron
    'Mixer Grinder': 500,  # Kitchen appliance
}

def generate_realistic_data():
    data = []
    start_date = datetime(2025, 3, 1)
    
    for day in range(30):  # Generate 30 days of data
        current_date = start_date + timedelta(days=day)
        for hour in range(24):
            current_time = current_date + timedelta(hours=hour)
            
            # Morning peak (7-9 AM)
            morning_peak = 7 <= hour <= 9
            # Evening peak (6-10 PM)
            evening_peak = 18 <= hour <= 22
            
            for appliance in APPLIANCE_POWER.keys():
                # Base consumption
                base_consumption = APPLIANCE_POWER[appliance] / 1000  # Convert to kWh
                
                # Apply realistic patterns
                if appliance == 'AC':
                    if 13 <= hour <= 16 or evening_peak:  # Hot afternoon and evening
                        consumption = base_consumption
                    else:
                        consumption = 0
                elif appliance == 'Light Bulbs':
                    if hour < 6 or hour >= 18:  # Dark hours
                        consumption = base_consumption
                    else:
                        consumption = 0
                else:
                    # Other appliances with typical usage patterns
                    if morning_peak or evening_peak:
                        consumption = base_consumption * np.random.uniform(0.8, 1.0)
                    else:
                        consumption = base_consumption * np.random.uniform(0.2, 0.4)
                
                data.append({
                    'timestamp': current_time,
                    'appliance': appliance,
                    'consumption_kwh': consumption
                })
    
    df = pd.DataFrame(data)
    df.to_csv('electricity_data.csv', index=False)
    print("Realistic sample data generated as 'electricity_data.csv'")

if __name__ == "__main__":
    generate_realistic_data()