import pandas as pd
import numpy as np
from datetime import datetime, timedelta

def generate_sample_data():
    # Generate 30 days of historical data
    dates = pd.date_range(start='2025-03-01', end='2025-03-31', freq='H')
    data = {
        'timestamp': dates,
        'watts': np.random.normal(1000, 200, len(dates)),  # Base load
        'temperature': np.random.normal(22, 5, len(dates)),
        'day_of_week': [d.weekday() for d in dates],
        'hour': [d.hour for d in dates],
        'occupancy': np.random.choice([0, 1], size=len(dates), p=[0.3, 0.7])
    }
    
    # Add patterns
    data['watts'] += np.where(data['hour'].isin([7,8,18,19,20]), 500, 0)  # Peak hours
    data['watts'] += data['temperature'] * 10  # Temperature impact
    data['watts'] += np.where(data['occupancy'] == 1, 300, 0)  # Occupancy impact
    
    return pd.DataFrame(data)