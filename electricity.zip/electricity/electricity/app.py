import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime
import plotly.express as px
import plotly.graph_objects as go
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler
import io
import time as time_module  # Import time module with alias
from collections import defaultdict
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, landscape
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch

# Constants
PRICE_PER_UNIT = 8.0  # Base price per unit in rupees
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'csv'}

def calculate_energy_reward(current_consumption, previous_consumption, hour):
    peak_hours = set(range(18, 22))
    
    if previous_consumption > 0:
        percent_change = (previous_consumption - current_consumption) / previous_consumption
    else:
        percent_change = 0
    
    reward = percent_change * 10
    
    if hour in peak_hours:
        reward -= current_consumption * 0.8
    
    if 23 <= hour <= 5:
        reward += 2.0
    elif 9 <= hour <= 17:
        reward += 1.0
    
    return reward

def create_detailed_consumption_chart(hourly_data, optimized_consumption):
    fig = go.Figure()

    # Update existing traces with more detailed styling
    fig.add_trace(go.Scatter(
        x=hourly_data.index,
        y=hourly_data.sum(axis=1),
        name='Current Usage',
        mode='lines+markers',
        line=dict(color='#e23636', width=3, dash='solid'),
        marker=dict(
            size=10,
            color='#e23636',
            symbol='circle',
            line=dict(color='#ffffff', width=2),
            opacity=0.8
        ),
        fill='tozeroy',
        fillcolor='rgba(226, 54, 54, 0.1)',
        hovertemplate='<b>Hour</b>: %{x}:00<br>' +
                     '<b>Usage</b>: %{y:.2f} kWh<br>' +
                     '<extra></extra>'
    ))

    fig.add_trace(go.Scatter(
        x=optimized_consumption.index,
        y=optimized_consumption.sum(axis=1),
        name='AI Optimized',
        mode='lines+markers',
        line=dict(color='#36e2a6', width=3),
        marker=dict(
            size=8,
            color='#36e2a6',
            symbol='circle',
            line=dict(color='#ffffff', width=1)
        ),
        fill='tozeroy',
        fillcolor='rgba(54, 226, 166, 0.1)',
        hovertemplate='Hour: %{x}:00<br>Optimized: %{y:.2f} kWh<extra></extra>'
    ))

    time_periods = [
        {'name': 'Night', 'range': (0, 5), 'color': 'rgba(0,0,0,0.1)'},
        {'name': 'Morning Peak', 'range': (6, 9), 'color': 'rgba(255,165,0,0.1)'},
        {'name': 'Day Time', 'range': (10, 17), 'color': 'rgba(255,255,0,0.1)'},
        {'name': 'Evening Peak', 'range': (18, 22), 'color': 'rgba(255,0,0,0.1)'},
        {'name': 'Late Night', 'range': (23, 24), 'color': 'rgba(0,0,0,0.1)'}
    ]

    for period in time_periods:
        fig.add_vrect(
            x0=period['range'][0],
            x1=period['range'][1],
            fillcolor=period['color'],
            opacity=0.2,
            layer="below",
            line_width=0,
            annotation_text=period['name'],
            annotation_position="top left"
        )

    fig.update_layout(
        title={
            'text': "24-Hour Electricity Consumption Analysis",
            'y':0.95,
            'x':0.5,
            'xanchor': 'center',
            'yanchor': 'top',
            'font': dict(size=24, color='white')
        },
        xaxis=dict(
            title="Hour of Day",
            tickmode='array',
            ticktext=['12 AM', '3 AM', '6 AM', '9 AM', '12 PM', '3 PM', '6 PM', '9 PM'],
            tickvals=[0, 3, 6, 9, 12, 15, 18, 21],
            gridcolor='rgba(255,255,255,0.1)',
            showgrid=True
        ),
        yaxis=dict(
            title="Consumption (kWh)",
            gridcolor='rgba(255,255,255,0.1)',
            showgrid=True
        ),
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        font=dict(color="white", size=14),
        hovermode='x unified',
        showlegend=True,
        legend=dict(
            yanchor="top",
            y=0.99,
            xanchor="left",
            x=0.01,
            bgcolor="rgba(0,0,0,0.5)",
            bordercolor="white",
            borderwidth=1
        ),
        margin=dict(t=100, l=70, r=40, b=50)
    )

    fig.update_xaxes(rangeslider_visible=True)
    return fig

class LoadPredictor:
    def __init__(self):
        self.model = RandomForestRegressor(
            n_estimators=100,
            random_state=42
        )
        self.scaler = StandardScaler()
        
    def prepare_features(self, historical_data):
        """Prepare features for load prediction"""
        features = []
        for hour in historical_data.index:
            feature_dict = {
                'hour': hour,
                'is_peak_hour': 1 if 17 <= hour <= 22 else 0,
                'is_night': 1 if hour < 6 or hour > 22 else 0,
                'is_working_hour': 1 if 9 <= hour <= 17 else 0,
                'total_load': historical_data.loc[hour].sum()
            }
            features.append(feature_dict)
            
        return pd.DataFrame(features)
    
    def train(self, historical_data):
        """Train the load prediction model"""
        X = self.prepare_features(historical_data)
        y = historical_data.sum(axis=1).values
        
        # Scale features
        X_scaled = self.scaler.fit_transform(X)
        
        # Train model
        self.model.fit(X_scaled, y)
        
    def predict_next_day_load(self, historical_data):
        """Predict next day's load"""
        X = self.prepare_features(historical_data)
        X_scaled = self.scaler.transform(X)
        predictions = self.model.predict(X_scaled)
        
        return predictions

class ApplianceOptimizer:
    def __init__(self):
        self.appliance_profiles = {
            'Air Conditioner': {
                'peak_threshold': 1.5,
                'efficiency_factor': 0.8,
                'tips': [
                    "Set temperature to 24°C for optimal efficiency",
                    "Clean filters regularly",
                    "Use during off-peak hours when possible",
                    "Consider using fans along with AC",
                    "Ensure proper insulation"
                ]
            },
            'Refrigerator': {
                'peak_threshold': 0.8,
                'efficiency_factor': 0.9,
                'tips': [
                    "Keep temperature between 3-5°C",
                    "Ensure door seals are tight",
                    "Don't put hot food directly in fridge",
                    "Regular defrosting if required",
                    "Keep coils clean and uncovered"
                ]
            },
            'Washing Machine': {
                'peak_threshold': 0.6,
                'efficiency_factor': 0.85,
                'tips': [
                    "Use full loads only",
                    "Use cold water when possible",
                    "Run during off-peak hours",
                    "Use appropriate water level",
                    "Clean filter regularly"
                ]
            },
            'Water Heater': {
                'peak_threshold': 2.0,
                'efficiency_factor': 0.75,
                'tips': [
                    "Set temperature to 60°C",
                    "Use timer to avoid peak hours",
                    "Insulate hot water pipes",
                    "Regular maintenance",
                    "Consider solar water heating"
                ]
            },
            'Iron': {
                'peak_threshold': 1.0,
                'efficiency_factor': 0.85,
                'tips': [
                    "Iron multiple clothes in one session",
                    "Use during off-peak hours",
                    "Sort clothes by temperature requirements",
                    "Clean the iron surface regularly",
                    "Use appropriate temperature settings"
                ]
            },
            'Microwave': {
                'peak_threshold': 0.8,
                'efficiency_factor': 0.9,
                'tips': [
                    "Use microwave instead of oven for small portions",
                    "Keep the interior clean for efficiency",
                    "Use appropriate power settings",
                    "Avoid running empty",
                    "Use microwave-safe containers"
                ]
            },
            'Mixer Grinder': {
                'peak_threshold': 0.5,
                'efficiency_factor': 0.88,
                'tips': [
                    "Batch process ingredients",
                    "Maintain sharp blades for efficiency",
                    "Use appropriate speed settings",
                    "Regular cleaning and maintenance",
                    "Avoid overloading"
                ]
            }
        }
    
    def analyze_appliance_usage(self, appliance_data):
        """Analyze appliance usage patterns and generate recommendations"""
        recommendations = []
        
        # Define non-shiftable loads that shouldn't be in optimization recommendations
        non_shiftable_loads = [
            'Fan', 'Light Bulb', 'Lighting', 'Ceiling Fan', 'Table Fan', 'LED Light', 
            'Bulb', 'Tube Light', 'Light Bulbs', 'Light', 'TV', 'Television',
            'Desk Light', 'Desk Lamp', 'Lamp', 'Floor Lamp', 'Night Light',
            'CFL Bulb', 'Fluorescent Light', 'LED Lamp', 'LED Strip'
        ]
        
        for appliance, consumption in appliance_data.items():
            # Skip non-shiftable loads
            if any(non_shiftable_load.lower() in appliance.lower() for non_shiftable_load in non_shiftable_loads):
                continue
                
            if appliance in self.appliance_profiles:
                profile = self.appliance_profiles[appliance]
                
                # Calculate efficiency metrics
                is_inefficient = consumption > profile['peak_threshold']
                potential_saving = (consumption - (consumption * profile['efficiency_factor'])) if is_inefficient else 0
                monthly_saving = potential_saving * 30
                
                # Generate priority score
                priority_score = (consumption / profile['peak_threshold']) * 100 if is_inefficient else 0
                
                # Only include if it's a significant load (over 0.3 kWh consumption)
                if is_inefficient and consumption > 0.3:
                    recommendations.append({
                        'appliance': appliance,
                        'current_consumption': consumption,
                        'optimal_consumption': consumption * profile['efficiency_factor'],
                        'daily_potential_saving': potential_saving,
                        'monthly_potential_saving': monthly_saving,
                        'priority_score': min(priority_score, 100),
                        'efficiency_status': 'Needs Improvement' if priority_score > 70 else 'Moderate',
                        'specific_tips': profile['tips'],
                        'peak_usage_alert': consumption > profile['peak_threshold'] * 1.2
                    })
        
        # Sort recommendations by priority score
        recommendations.sort(key=lambda x: x['priority_score'], reverse=True)
        return recommendations

def calculate_hourly_cost(consumption, hour, hourly_rates):
    """Calculate cost based on hourly rates"""
    return consumption * hourly_rates[hour]

def process_uploaded_data(df, hourly_rates):
    """Process the uploaded CSV data and calculate insights"""
    try:
        # Ensure proper data types and handle timestamp
        if 'timestamp' not in df.columns or 'appliance' not in df.columns or 'consumption_kwh' not in df.columns:
            raise Exception("CSV file must contain 'timestamp', 'appliance', and 'consumption_kwh' columns")
        
        # Convert timestamp to datetime
        try:
            # First try with specific format
            df['timestamp'] = pd.to_datetime(df['timestamp'], format='%d-%m-%Y %H:%M')
        except ValueError:
            try:
                # If that fails, try automatic parsing
                df['timestamp'] = pd.to_datetime(df['timestamp'])
            except Exception as e:
                raise Exception(f"Error converting timestamp column: {str(e)}")

        # Convert consumption to numeric, handling errors
        df['consumption_kwh'] = pd.to_numeric(df['consumption_kwh'], errors='coerce')
        
        # Drop any rows with NaN values
        df = df.dropna(subset=['timestamp', 'appliance', 'consumption_kwh'])
        
        # Extract hour from timestamp for aggregation
        df['hour'] = df['timestamp'].dt.hour
        
        # Calculate daily totals per appliance
        daily_totals = df.groupby('appliance')['consumption_kwh'].sum()
        
        # Create hourly consumption data
        hourly_data = df.pivot_table(
            index='hour',
            columns='appliance',
            values='consumption_kwh',
            aggfunc='mean'
        ).fillna(0)
        
        # Initialize optimized consumption
        optimized_consumption = hourly_data.copy()
        recommendations = []
        total_potential_saving = 0
        
        # Process data in 4-hour blocks
        time_blocks = [
            {"name": "Early Morning", "hours": list(range(0, 4))},
            {"name": "Morning", "hours": list(range(4, 8))},
            {"name": "Mid Day", "hours": list(range(8, 12))},
            {"name": "Afternoon", "hours": list(range(12, 16))},
            {"name": "Evening", "hours": list(range(16, 20))},
            {"name": "Night", "hours": list(range(20, 24))}
        ]
        
        # Calculate optimization factors for each block
        for block in time_blocks:
            block_consumption = 0
            block_saving = 0
            
            for hour in block["hours"]:
                if hour in hourly_data.index:
                    total_consumption = hourly_data.loc[hour].sum()
                    block_consumption += total_consumption
                    
                    # Optimization factors based on time of day
                    if hour in range(18, 22):  # Peak hours
                        opt_factor = 0.75
                    elif hour in range(23, 5):  # Night hours
                        opt_factor = 0.85
                    else:
                        opt_factor = 0.90
                    
                        optimized_consumption.loc[hour] *= opt_factor
                    current_cost = total_consumption * hourly_rates[hour]
                    optimized_cost = optimized_consumption.loc[hour].sum() * hourly_rates[hour]
                    block_saving += current_cost - optimized_cost
            
            if block_saving > 0:
                recommendations.append({
                    'time_block': block["name"],
                    'hours': f"{min(block['hours']):02d}:00 - {max(block['hours'])+1:02d}:00",
                    'potential_saving': block_saving,
                    'consumption': block_consumption
                })
                total_potential_saving += block_saving
        
        # Initialize predictors and optimizers
        load_predictor = LoadPredictor()
        appliance_optimizer = ApplianceOptimizer()
        
        # Train load predictor and get predictions
        load_predictor.train(hourly_data)
        next_day_predictions = load_predictor.predict_next_day_load(hourly_data)
        
        # Get appliance recommendations
        appliance_recommendations = appliance_optimizer.analyze_appliance_usage(daily_totals)
        
        return {
            'hourly_data': hourly_data,
            'optimized_consumption': optimized_consumption,
            'recommendations': recommendations,
            'total_potential_saving': total_potential_saving,
            'daily_totals': daily_totals,
            'next_day_predictions': next_day_predictions,
            'appliance_recommendations': appliance_recommendations
        }
        
    except Exception as e:
        raise Exception(f"Error processing data: {str(e)}")

def create_price_analysis_chart(hourly_data, hourly_rates):
    """Create a chart showing consumption cost analysis based on hourly rates"""
    fig = go.Figure()

    # Calculate hourly costs
    hourly_costs = {}
    for hour in range(24):
        consumption = hourly_data.loc[hour].sum() if hour in hourly_data.index else 0
        hourly_costs[hour] = consumption * hourly_rates[hour]

    # Add hourly rate trace
    fig.add_trace(go.Scatter(
        x=list(range(24)),
        y=[hourly_rates[hour] for hour in range(24)],
        name='Rate (₹/kWh)',
        mode='lines+markers',
        line=dict(color='#f1c40f', width=3),
        marker=dict(
            size=8,
            symbol='circle',
            line=dict(color='#ffffff', width=1)
        ),
        yaxis='y2'
    ))

    # Add cost trace
    fig.add_trace(go.Bar(
        x=list(range(24)),
        y=list(hourly_costs.values()),
        name='Cost (₹)',
        marker_color='#3498db',
        opacity=0.7
    ))

    # Update layout with dual y-axes
    fig.update_layout(
        title={
            'text': "24-Hour Electricity Cost Analysis",
            'y':0.95,
            'x':0.5,
            'xanchor': 'center',
            'yanchor': 'top',
            'font': dict(size=24, color='white')
        },
        xaxis=dict(
            title="Hour of Day",
            tickmode='array',
            ticktext=['12 AM', '3 AM', '6 AM', '9 AM', '12 PM', '3 PM', '6 PM', '9 PM'],
            tickvals=[0, 3, 6, 9, 12, 15, 18, 21],
            gridcolor='rgba(255,255,255,0.1)',
            showgrid=True
        ),
        yaxis=dict(
            title="Cost (₹)",
            gridcolor='rgba(255,255,255,0.1)',
            showgrid=True
        ),
        yaxis2=dict(
            title="Rate (₹/kWh)",
            overlaying='y',
            side='right',
            gridcolor='rgba(255,255,255,0.1)',
        ),
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        font=dict(color="white", size=14),
        hovermode='x unified',
        showlegend=True,
        legend=dict(
            yanchor="top",
            y=0.99,
            xanchor="left",
            x=0.01,
            bgcolor="rgba(0,0,0,0.5)",
            bordercolor="white",
            borderwidth=1
        ),
        margin=dict(t=100, l=70, r=70, b=50)
    )

    # Add time period highlights
    time_periods = [
        {'name': 'Night', 'range': (0, 5), 'color': 'rgba(0,0,0,0.1)'},
        {'name': 'Morning Peak', 'range': (6, 9), 'color': 'rgba(255,165,0,0.1)'},
        {'name': 'Day Time', 'range': (10, 17), 'color': 'rgba(255,255,0,0.1)'},
        {'name': 'Evening Peak', 'range': (18, 22), 'color': 'rgba(255,0,0,0.1)'},
        {'name': 'Late Night', 'range': (23, 24), 'color': 'rgba(0,0,0,0.1)'}
    ]

    for period in time_periods:
        fig.add_vrect(
            x0=period['range'][0],
            x1=period['range'][1],
            fillcolor=period['color'],
            opacity=0.2,
            layer="below",
            line_width=0,
            annotation_text=period['name'],
            annotation_position="top left"
        )

    return fig

def create_appliance_optimization_chart(appliance_data, hourly_rates, recommendations, peak_hours=None, off_peak_hours=None, standard_hours=None):
    """Create a detailed optimization chart for appliance usage with customizable time periods"""
    fig = go.Figure()

    # Current usage pattern
    fig.add_trace(go.Scatter(
        x=list(range(24)),
        y=appliance_data,
        name='Current Usage',
        mode='lines+markers',
        line=dict(color='#e74c3c', width=3),
        marker=dict(size=8)
    ))

    # Use default time periods if not provided
    if peak_hours is None:
        peak_hours = list(range(18, 22))
    if off_peak_hours is None:
        off_peak_hours = list(range(23, 24)) + list(range(0, 6))
    if standard_hours is None:
        standard_hours = [h for h in range(24) if h not in peak_hours and h not in off_peak_hours]

    # Recommended usage pattern based on customized time periods
    recommended_usage = []
    for hour in range(24):
        if hour in off_peak_hours:  # Off-peak hours
            recommended_usage.append(appliance_data[hour] * 0.85)  # 15% reduction
        elif hour in peak_hours:  # Peak hours
            recommended_usage.append(appliance_data[hour] * 0.6)  # 40% reduction
        else:  # Standard hours
            recommended_usage.append(appliance_data[hour] * 0.8)  # 20% reduction

    fig.add_trace(go.Scatter(
        x=list(range(24)),
        y=recommended_usage,
        name='Recommended Usage',
        mode='lines+markers',
        line=dict(color='#2ecc71', width=3, dash='dash'),
        marker=dict(size=8)
    ))

    # Add rate information
    fig.add_trace(go.Scatter(
        x=list(range(24)),
        y=[hourly_rates[hour] for hour in range(24)],
        name='Rate (₹/kWh)',
        mode='lines',
        line=dict(color='#f1c40f', width=2),
        yaxis='y2'
    ))

    # Update layout
    fig.update_layout(
        title=f"24-Hour Usage Optimization Guide",
        xaxis=dict(
            title="Hour of Day",
            tickmode='array',
            ticktext=['12 AM', '3 AM', '6 AM', '9 AM', '12 PM', '3 PM', '6 PM', '9 PM'],
            tickvals=[0, 3, 6, 9, 12, 15, 18, 21],
            gridcolor='rgba(255,255,255,0.1)'
        ),
        yaxis=dict(
            title="Energy Consumption (kWh)",
            gridcolor='rgba(255,255,255,0.1)'
        ),
        yaxis2=dict(
            title="Rate (₹/kWh)",
            overlaying='y',
            side='right',
            gridcolor='rgba(255,255,255,0.1)'
        ),
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        font=dict(color='white'),
        hovermode='x unified',
        showlegend=True,
        legend=dict(
            yanchor="top",
            y=0.99,
            xanchor="left",
            x=0.01,
            bgcolor="rgba(0,0,0,0.5)"
        )
    )

    # Create time periods based on the provided custom hour ranges
    time_periods = []
    
    # Add best usage time (standard hours with best efficiency)
    if standard_hours:
        # Find the longest continuous block of standard hours
        blocks = []
        current_block = []
        
        for hour in sorted(standard_hours):
            if not current_block or hour == current_block[-1] + 1:
                current_block.append(hour)
            else:
                blocks.append(current_block)
                current_block = [hour]
                
        if current_block:
            blocks.append(current_block)
            
        if blocks:
            best_block = max(blocks, key=len)
            time_periods.append({
                'name': 'Best Usage Time',
                'range': (min(best_block), max(best_block) + 1),
                'color': 'rgba(46, 204, 113, 0.1)'
            })
    
    # Add peak hours to avoid
    if peak_hours:
        time_periods.append({
            'name': 'Peak Hours (Avoid)',
            'range': (min(peak_hours), max(peak_hours) + 1),
            'color': 'rgba(231, 76, 60, 0.1)'
        })
    
    # Add economy hours
    if off_peak_hours:
        if min(off_peak_hours) > max(off_peak_hours):
            # Handle overnight periods - split into two
            night_hours_1 = [h for h in off_peak_hours if h >= 12]
            night_hours_2 = [h for h in off_peak_hours if h < 12]
            
            if night_hours_1:
                time_periods.append({
                    'name': 'Economy Hours',
                    'range': (min(night_hours_1), 24),
                    'color': 'rgba(52, 152, 219, 0.1)'
                })
            
            if night_hours_2:
                time_periods.append({
                    'name': 'Economy Hours',
                    'range': (0, max(night_hours_2) + 1),
                    'color': 'rgba(52, 152, 219, 0.1)'
                })
        else:
            time_periods.append({
                'name': 'Economy Hours',
                'range': (min(off_peak_hours), max(off_peak_hours) + 1),
                'color': 'rgba(52, 152, 219, 0.1)'
            })

    for period in time_periods:
        fig.add_vrect(
            x0=period['range'][0],
            x1=period['range'][1],
            fillcolor=period['color'],
            opacity=0.3,
            layer="below",
            line_width=0,
            annotation_text=period['name'],
            annotation_position="top left"
        )

    return fig

def get_appliance_tips(appliance):
    """Get specific tips for each appliance with advantages and consequences"""
    tips = {
        'Air Conditioner': [
            {
                'tip': "Set temperature to 24°C for optimal efficiency",
                'advantage': "Save up to 6% energy per degree above 22°C; monthly savings of ₹200-300",
                'consequence': "Setting below 24°C increases power consumption by 6-8% per degree, leading to ₹300-400 extra cost monthly"
            },
            {
                'tip': "Clean filters regularly (every 2-3 weeks)",
                'advantage': "Improves efficiency by 15%, saves ₹150-200 monthly, extends AC life by 2-3 years",
                'consequence': "Dirty filters reduce efficiency by 20%, increase electricity cost by ₹250-300 monthly, and may lead to repairs costing ₹2000-3000"
            },
            {
                'tip': "Use during off-peak hours when possible",
                'advantage': "Save 30-40% on electricity costs during off-peak hours, potential monthly savings of ₹400-500",
                'consequence': "Peak hour usage costs 40% more, adding ₹500-600 to monthly bills"
            },
            {
                'tip': "Use fans along with AC",
                'advantage': "Reduces AC workload by 30%, saves ₹200-300 monthly on electricity",
                'consequence': "AC working alone uses 40% more power, increasing monthly bill by ₹300-400"
            },
            {
                'tip': "Ensure proper insulation",
                'advantage': "Reduces cooling loss by 30%, saves ₹250-300 monthly on electricity",
                'consequence': "Poor insulation increases cooling costs by 35%, wastes ₹300-400 monthly"
            }
        ],
        'Refrigerator': [
            {
                'tip': "Keep temperature between 3-5°C",
                'advantage': "Optimal efficiency saving 15% energy, ₹100-150 monthly savings",
                'consequence': "Every degree colder increases energy use by 5%, adding ₹50-75 to monthly bills"
            },
            {
                'tip': "Ensure door seals are tight",
                'advantage': "Prevents 20% cooling loss, saves ₹120-150 monthly",
                'consequence': "Damaged seals waste 25% energy, increase bill by ₹150-200 monthly, may spoil food"
            },
            {
                'tip': "Don't put hot food directly in fridge",
                'advantage': "Reduces energy consumption by 10%, saves ₹80-100 monthly",
                'consequence': "Hot food raises internal temperature, increases energy use by 15%, costs extra ₹100-120 monthly"
            },
            {
                'tip': "Regular defrosting if required",
                'advantage': "Improves efficiency by 30%, saves ₹200-250 monthly",
                'consequence': "Ice buildup reduces efficiency by 35%, wastes ₹250-300 monthly, shortens appliance life"
            },
            {
                'tip': "Keep coils clean and uncovered",
                'advantage': "Improves efficiency by 25%, saves ₹150-200 monthly",
                'consequence': "Dirty coils reduce efficiency by 30%, increase electricity cost by ₹200-250 monthly"
            }
        ],
        'Washing Machine': [
            {
                'tip': "Use full loads only",
                'advantage': "Saves 30% water and energy, reduces bill by ₹150-200 monthly",
                'consequence': "Half loads waste 50% more water and energy per kg, adds ₹200-250 to monthly bills"
            },
            {
                'tip': "Use cold water when possible",
                'advantage': "Saves 90% energy per load, reduces electricity bill by ₹100-150 monthly",
                'consequence': "Hot water unnecessarily increases energy use by 90%, adds ₹150-200 to monthly costs"
            },
            {
                'tip': "Run during off-peak hours",
                'advantage': "Save 30% on electricity costs, potential savings of ₹120-150 monthly",
                'consequence': "Peak hour usage costs 40% more, adds ₹150-180 to monthly bills"
            },
            {
                'tip': "Use appropriate water level",
                'advantage': "Saves 25% water and energy, reduces bills by ₹100-120 monthly",
                'consequence': "Excess water wastes 30% energy, increases cost by ₹120-150 monthly"
            },
            {
                'tip': "Clean filter regularly",
                'advantage': "Improves efficiency by 20%, saves ₹100-120 monthly",
                'consequence': "Clogged filter reduces efficiency by 25%, increases bills by ₹120-150 monthly"
            }
        ],
        'Water Heater': [
            {
                'tip': "Set temperature to 60°C",
                'advantage': "Optimal efficiency saving 10% energy, ₹100-150 monthly savings",
                'consequence': "Higher temperatures waste 15% energy, add ₹150-200 to monthly bills"
            },
            {
                'tip': "Use timer to avoid peak hours",
                'advantage': "Save 40% on heating costs, reduces bill by ₹200-250 monthly",
                'consequence': "Peak hour usage costs 50% more, adds ₹250-300 to monthly bills"
            },
            {
                'tip': "Insulate hot water pipes",
                'advantage': "Reduces heat loss by 25%, saves ₹150-200 monthly",
                'consequence': "Uninsulated pipes waste 30% heat, increase costs by ₹200-250 monthly"
            },
            {
                'tip': "Regular maintenance",
                'advantage': "Extends life by 5 years, improves efficiency by 15%, saves ₹150-200 monthly",
                'consequence': "Poor maintenance reduces efficiency by 20%, increases bills by ₹200-250 monthly"
            },
            {
                'tip': "Consider solar water heating",
                'advantage': "Saves up to 80% on water heating costs, potential savings of ₹500-600 monthly",
                'consequence': "Relying solely on electric heating costs 4-5 times more, adds ₹600-700 to monthly bills"
            }
        ]
    }
    
    default_tips = [
        {
            'tip': "Optimize usage during off-peak hours",
            'advantage': "Save 30-40% on electricity costs, potential monthly savings of ₹200-300",
            'consequence': "Peak hour usage increases costs by 40-50%, adds ₹300-400 to monthly bills"
        },
        {
            'tip': "Regular maintenance recommended",
            'advantage': "Improves efficiency by 20-25%, extends appliance life by 2-3 years",
            'consequence': "Poor maintenance reduces efficiency by 30%, increases running costs by 25%"
        }
    ]
    
    return tips.get(appliance, default_tips)

def create_savings_comparison_chart(current_usage, recommended_usage, hourly_rates):
    """Create a chart comparing current vs recommended usage patterns and showing potential savings"""
    fig = go.Figure()

    # Calculate costs
    current_costs = [current_usage[hour] * hourly_rates[hour] for hour in range(24)]
    recommended_costs = [recommended_usage[hour] * hourly_rates[hour] for hour in range(24)]
    savings = [current_costs[hour] - recommended_costs[hour] for hour in range(24)]
    
    # Current usage pattern
    fig.add_trace(go.Scatter(
        x=list(range(24)),
        y=current_costs,
        name='Current Cost',
        mode='lines+markers',
        line=dict(color='#e74c3c', width=3),
        marker=dict(size=8)
    ))

    # Recommended usage pattern
    fig.add_trace(go.Scatter(
        x=list(range(24)),
        y=recommended_costs,
        name='Recommended Cost',
        mode='lines+markers',
        line=dict(color='#2ecc71', width=3),
        marker=dict(size=8)
    ))

    # Add savings as a bar chart
    fig.add_trace(go.Bar(
        x=list(range(24)),
        y=savings,
        name='Hourly Savings',
        marker_color='#3498db',
        opacity=0.5
    ))

    # Update layout
    fig.update_layout(
        title={
            'text': "Cost Savings Analysis: Current vs Recommended Usage",
            'y': 0.95,
            'x': 0.5,
            'xanchor': 'center',
            'yanchor': 'top',
            'font': dict(size=24, color='white')
        },
        xaxis=dict(
            title="Hour of Day",
            tickmode='array',
            ticktext=['12 AM', '3 AM', '6 AM', '9 AM', '12 PM', '3 PM', '6 PM', '9 PM'],
            tickvals=[0, 3, 6, 9, 12, 15, 18, 21],
            gridcolor='rgba(255,255,255,0.1)'
        ),
        yaxis=dict(
            title="Cost (₹)",
            gridcolor='rgba(255,255,255,0.1)'
        ),
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        font=dict(color='white'),
        hovermode='x unified',
        showlegend=True,
        legend=dict(
            yanchor="top",
            y=0.99,
            xanchor="left",
            x=0.01,
            bgcolor="rgba(0,0,0,0.5)"
        )
    )

    # Add time period highlights
    time_periods = [
        {'name': 'Off-Peak Hours', 'range': (0, 6), 'color': 'rgba(46, 204, 113, 0.1)'},
        {'name': 'Peak Hours', 'range': (18, 22), 'color': 'rgba(231, 76, 60, 0.1)'},
        {'name': 'Standard Hours', 'range': (6, 18), 'color': 'rgba(52, 152, 219, 0.1)'},
        {'name': 'Night Hours', 'range': (22, 24), 'color': 'rgba(46, 204, 113, 0.1)'}
    ]

    for period in time_periods:
        fig.add_vrect(
            x0=period['range'][0],
            x1=period['range'][1],
            fillcolor=period['color'],
            opacity=0.3,
            layer="below",
            line_width=0,
            annotation_text=period['name'],
            annotation_position="top left"
        )

    return fig

def create_bill_comparison_chart(current_bill, recommended_bill):
    """Create a visual comparison between current and recommended electricity bills"""
    # Create monthly and yearly projections
    timeframes = ["Daily", "Weekly", "Monthly", "Yearly"]
    multipliers = [1, 7, 30, 365]
    
    current_costs = [current_bill * m for m in multipliers]
    recommended_costs = [recommended_bill * m for m in multipliers]
    savings = [current_costs[i] - recommended_costs[i] for i in range(len(timeframes))]
    savings_percentage = [(savings[i] / current_costs[i]) * 100 for i in range(len(timeframes))]
    
    # Create figure
    fig = go.Figure()
    
    # Add bars for current bill
    fig.add_trace(go.Bar(
        x=timeframes,
        y=current_costs,
        name='Current Bill',
        marker_color='#e74c3c',
        text=[f"₹{cost:.2f}" for cost in current_costs],
        textposition='auto'
    ))
    
    # Add bars for recommended bill
    fig.add_trace(go.Bar(
        x=timeframes,
        y=recommended_costs,
        name='Recommended Bill',
        marker_color='#2ecc71',
        text=[f"₹{cost:.2f}" for cost in recommended_costs],
        textposition='auto'
    ))
    
    # Add annotations for savings
    for i, timeframe in enumerate(timeframes):
        fig.add_annotation(
            x=timeframe,
            y=current_costs[i],
            text=f"Save {savings_percentage[i]:.1f}%<br>₹{savings[i]:.2f}",
            showarrow=True,
            arrowhead=1,
            arrowcolor="#3498db",
            arrowsize=1,
            arrowwidth=2,
            ax=0,
            ay=-40
        )
    
    # Update layout
    fig.update_layout(
        title={
            'text': "Bill Comparison: Current vs Recommended",
            'y': 0.95,
            'x': 0.5,
            'xanchor': 'center',
            'yanchor': 'top',
            'font': dict(size=24, color='white')
        },
        xaxis=dict(
            title="Timeframe",
            gridcolor='rgba(255,255,255,0.1)'
        ),
        yaxis=dict(
            title="Cost (₹)",
            gridcolor='rgba(255,255,255,0.1)'
        ),
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        font=dict(color='white'),
        barmode='group',
        bargap=0.15,
        bargroupgap=0.1,
        legend=dict(
            yanchor="top",
            y=0.99,
            xanchor="right",
            x=0.99,
            bgcolor="rgba(0,0,0,0.5)"
        )
    )
    
    return fig

def validate_csv_data(df):
    """Validate the CSV data format and return error messages if any"""
    errors = []
    
    # Check for required columns
    required_columns = ['timestamp', 'appliance', 'consumption_kwh']
    for col in required_columns:
        if col not in df.columns:
            errors.append(f"Missing required column: {col}")
    
    if errors:
        return False, errors
    
    # Check data types and formats
    try:
        # Try converting timestamp
        pd.to_datetime(df['timestamp'], format='mixed')
    except Exception as e:
        errors.append(f"Invalid timestamp format: {str(e)}")
    
    # Check for empty values
    for col in required_columns:
        if df[col].isna().any():
            errors.append(f"Column '{col}' contains empty values")
    
    # Check for negative consumption values
    if (df['consumption_kwh'] < 0).any():
        errors.append("Consumption values cannot be negative")
    
    return len(errors) == 0, errors

def main():
    st.set_page_config(
        page_title="Smart Energy Analyzer",
        layout="wide",
        initial_sidebar_state="collapsed"
    )

    # Add page background and configuration
    st.markdown("""
    <style>
    .stApp {
        background: linear-gradient(180deg, #1a1a1a 0%, #0a192f 100%);
        color: white;
    }
    /* Hide unnecessary elements */
    #MainMenu, header, footer {
        visibility: hidden;
    }
    .block-container {
        padding-top: 1rem;
        padding-bottom: 0rem;
    }
    .metric-card {
        background: rgba(52, 152, 219, 0.1);
        padding: 15px;
        border-radius: 10px;
        margin: 10px 0;
    }
    .metric-card h4 {
        color: #3498db;
        margin-bottom: 10px;
    }
    .metric-card p {
        margin: 5px 0;
    }
    .tip-item {
        background: rgba(52, 152, 219, 0.1);
        padding: 10px 15px;
        border-radius: 5px;
        margin: 5px 0;
        border-left: 3px solid #3498db;
    }
    </style>
    """, unsafe_allow_html=True)

    # Header Section - Simplified
    st.markdown("<h1 style='text-align: center; color: #3498db; margin-top: -1rem;'>⚡ Smart Energy Analyzer</h1>", unsafe_allow_html=True)
    st.markdown("<p style='text-align: center; color: #3498db; font-size: 1.2em;'>Transform Your Energy Consumption with AI</p>", unsafe_allow_html=True)

    # Features Section
    st.markdown("---")
    col1, col2 = st.columns(2)
    
    with col1:
        with st.container():
            st.markdown("### 🎯 Smart Features")
            features = [
                "🤖 AI-Powered Analysis",
                "💰 Cost Optimization",
                "⏰ Peak Usage Detection",
                "📊 Usage Patterns",
                "💡 Smart Recommendations"
            ]
            for feature in features:
                st.markdown(f"- {feature}")

    with col2:
        with st.container():
            st.markdown("### 📈 Benefits")
            benefits = [
                "🔸 Up to 25% Cost Reduction",
                "🔸 ₹1000-3000 Monthly Savings",
                "🔸 Optimized Peak Hour Usage",
                "🔸 Lower Carbon Footprint",
                "🔸 Better Energy Habits"
            ]
            for benefit in benefits:
                st.markdown(f"- {benefit}")

    # Tips Section
    st.markdown("---")
    st.markdown("### 💡 Energy Saving Tips")
    col1, col2, col3 = st.columns(3)

    with col1:
        with st.expander("🌙 Peak Hours (6 PM - 10 PM)", expanded=True):
            st.markdown("""
            - Avoid running multiple appliances
            - Use timer switches for geysers
            - Opt for natural ventilation
            - Schedule heavy appliance usage
            """)

    with col2:
        with st.expander("⚡ Smart Appliance Usage", expanded=True):
            st.markdown("""
            - Set AC temperature to 24°C
            - Use star-rated appliances
            - Regular maintenance checks
            - Full loads for washing machine
            """)

    with col3:
        with st.expander("📝 Daily Habits", expanded=True):
            st.markdown("""
            - Turn off unused devices
            - Maximize natural light
            - Use power strips
            - Track daily consumption
            """)

    # Upload Section
    st.markdown("---")
    st.markdown("### 📤 Upload Your Data")
    
    # Replace the slab rate configuration with hourly rates
    st.markdown("### 💰 Hourly Electricity Rate Configuration")
    st.markdown("""
    <div style='text-align: center; padding: 20px; border-radius: 10px; border: 2px dashed #3498db; margin-bottom: 20px;'>
        <h4 style='color: #3498db;'>Set Hourly Electricity Rates</h4>
        <p style='color: #7f8c8d;'>Enter the price per unit (kWh) for each hour of the day</p>
    </div>
    """, unsafe_allow_html=True)

    # Add customization for time periods first (move this section before hourly rates)
    st.markdown("### ⏰ Customize Time Periods")
    st.markdown("""
    <div style='text-align: center; padding: 20px; border-radius: 10px; border: 2px dashed #3498db; margin-bottom: 20px;'>
        <h4 style='color: #3498db;'>Customize Your Time Periods</h4>
        <p style='color: #7f8c8d;'>Define your own peak hours, off-peak hours, and other time periods for more accurate analysis</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Create columns for different time period settings
    period_col1, period_col2 = st.columns(2)
    
    with period_col1:
        st.markdown("#### 🔴 Peak Hours")
        peak_start = st.slider("Peak Hours Start", 0, 23, 18, 1, key="peak_start", 
                             format="%d:00", help="Start of peak hours (higher electricity rates)")
        peak_end = st.slider("Peak Hours End", 0, 23, 22, 1, key="peak_end", 
                           format="%d:00", help="End of peak hours (higher electricity rates)")
        if peak_start > peak_end:
            st.warning("⚠️ Peak start hour should be before peak end hour")
            peak_hours = list(range(18, 22))  # Default
        else:
            peak_hours = list(range(peak_start, peak_end + 1))
            
        st.markdown(f"**Selected Peak Hours:** {min(peak_hours):02d}:00 - {max(peak_hours):02d}:00")
    
    with period_col2:
        st.markdown("#### 🟢 Off-Peak Hours")
        off_peak_options = ["Night (11 PM - 5 AM)", "Early Morning (5 AM - 9 AM)", "Mid-Day (10 AM - 4 PM)", "Late Night (10 PM - 12 AM)", "Custom"]
        off_peak_choice = st.selectbox("Select Off-Peak Period", off_peak_options, index=0, key="off_peak_choice")
        
        if off_peak_choice == "Night (11 PM - 5 AM)":
            off_peak_hours = list(range(23, 24)) + list(range(0, 6))
        elif off_peak_choice == "Early Morning (5 AM - 9 AM)":
            off_peak_hours = list(range(5, 9))
        elif off_peak_choice == "Mid-Day (10 AM - 4 PM)":
            off_peak_hours = list(range(10, 16))
        elif off_peak_choice == "Late Night (10 PM - 12 AM)":
            off_peak_hours = list(range(22, 24))
        else:  # Custom
            off_peak_start = st.slider("Off-Peak Start", 0, 23, 23, 1, key="off_peak_start", format="%d:00")
            off_peak_end = st.slider("Off-Peak End", 0, 23, 5, 1, key="off_peak_end", format="%d:00")
            if off_peak_start > off_peak_end:
                # Handle overnight periods
                off_peak_hours = list(range(off_peak_start, 24)) + list(range(0, off_peak_end + 1))
            else:
                off_peak_hours = list(range(off_peak_start, off_peak_end + 1))
                
        st.markdown(f"**Selected Off-Peak Hours:** {', '.join([f'{h:02d}:00' for h in sorted(off_peak_hours)])}")
        
    # Standard hours are neither peak nor off-peak
    standard_hours = [h for h in range(24) if h not in peak_hours and h not in off_peak_hours]
    
    # Create 6 columns for 4-hour blocks
    cols = st.columns(6)
    
    # Initialize hourly_rates dictionary with default values
    hourly_rates = {}
    for hour in range(24):
        if hour < 4:
            hourly_rates[hour] = 5.0  # night
        elif hour < 8:
            hourly_rates[hour] = 6.0  # early_morning
        elif hour < 12:
            hourly_rates[hour] = 8.0  # morning
        elif hour < 16:
            hourly_rates[hour] = 7.0  # afternoon
        elif hour < 20:
            hourly_rates[hour] = 9.0  # evening
        else:
            hourly_rates[hour] = 10.0  # late_evening

    # Option to automatically adjust electricity rates based on selected time periods
    st.markdown("#### 💰 Electricity Rate Adjustment")
    
    auto_adjust_rates = st.checkbox("Automatically adjust electricity rates based on time periods", value=False)
    
    if auto_adjust_rates:
        col1, col2, col3 = st.columns(3)
        
        with col1:
            peak_rate_multiplier = st.slider("Peak hours rate multiplier", 
                                           min_value=1.0, max_value=2.0, value=1.5, step=0.1,
                                           help="Multiply standard rates during peak hours by this factor")
        
        with col2:
            off_peak_rate_multiplier = st.slider("Off-peak hours rate multiplier", 
                                              min_value=0.5, max_value=1.0, value=0.8, step=0.1,
                                              help="Multiply standard rates during off-peak hours by this factor")
        
        with col3:
            st.markdown("<div style='margin-top: 40px;'>Standard hours: 1.0x (no change)</div>", unsafe_allow_html=True)
        
        # Store original rates to allow resetting them when adjusting
        original_rates = hourly_rates.copy()
        
        # Calculate average rates for each time period type
        peak_hours_rates = [original_rates[h] for h in peak_hours]
        off_peak_hours_rates = [original_rates[h] for h in off_peak_hours]
        standard_hours_rates = [original_rates[h] for h in standard_hours]
        
        peak_avg = sum(peak_hours_rates) / len(peak_hours_rates) if peak_hours_rates else 0
        off_peak_avg = sum(off_peak_hours_rates) / len(off_peak_hours_rates) if off_peak_hours_rates else 0
        standard_avg = sum(standard_hours_rates) / len(standard_hours_rates) if standard_hours_rates else 0
        
        # Apply rate multipliers based on time periods
        for hour in range(24):
            if hour in peak_hours:
                hourly_rates[hour] = round(original_rates[hour] * peak_rate_multiplier, 1)
            elif hour in off_peak_hours:
                hourly_rates[hour] = round(original_rates[hour] * off_peak_rate_multiplier, 1)
        
        # Calculate the new averages after adjustment
        new_peak_avg = sum([hourly_rates[h] for h in peak_hours]) / len(peak_hours) if peak_hours else 0
        new_off_peak_avg = sum([hourly_rates[h] for h in off_peak_hours]) / len(off_peak_hours) if off_peak_hours else 0
        
        st.success(f"""✅ Rates adjusted! 
                   Peak hours: ₹{new_peak_avg:.1f}/kWh ({"+" if new_peak_avg > peak_avg else ""}{((new_peak_avg/peak_avg)-1)*100:.0f}%), 
                   Off-peak hours: ₹{new_off_peak_avg:.1f}/kWh ({((new_off_peak_avg/off_peak_avg)-1)*100:.0f}%), 
                   Standard hours: unchanged""")
    
    # Update the hourly rate input section to display time periods
    st.markdown("#### 💰 Hourly Electricity Rate Input")
    
    # Legend for time period colors
    legend_col1, legend_col2, legend_col3 = st.columns(3)
    with legend_col1:
        st.markdown("<div style='background-color: rgba(231, 76, 60, 0.3); padding: 10px; border-radius: 5px; text-align: center; color: white;'>🔴 Peak Hours</div>", unsafe_allow_html=True)
    with legend_col2:
        st.markdown("<div style='background-color: rgba(46, 204, 113, 0.3); padding: 10px; border-radius: 5px; text-align: center; color: white;'>🟢 Off-Peak Hours</div>", unsafe_allow_html=True)
    with legend_col3:
        st.markdown("<div style='background-color: rgba(52, 152, 219, 0.3); padding: 10px; border-radius: 5px; text-align: center; color: white;'>🔵 Standard Hours</div>", unsafe_allow_html=True)
    
    # Function to determine the background color based on time period
    def get_hour_period_style(hour):
        if hour in peak_hours:
            return "rgba(231, 76, 60, 0.3)"  # Darker red for peak hours
        elif hour in off_peak_hours:
            return "rgba(46, 204, 113, 0.3)"  # Darker green for off-peak hours
        else:
            return "rgba(52, 152, 219, 0.3)"  # Darker blue for standard hours

    # Create input fields for each 4-hour block
    for i, col in enumerate(cols):
        start_hour = i * 4
        with col:
            st.markdown(f"##### {start_hour:02d}:00 - {(start_hour + 4):02d}:00")
            for hour in range(start_hour, start_hour + 4):
                # Set default rate based on time period
                if hour < 4:
                    default_rate = 5.0  # night
                elif hour < 8:
                    default_rate = 6.0  # early_morning
                elif hour < 12:
                    default_rate = 8.0  # morning
                elif hour < 16:
                    default_rate = 7.0  # afternoon
                elif hour < 20:
                    default_rate = 9.0  # evening
                else:
                    default_rate = 10.0  # late_evening

                # Get the background color based on the time period
                bg_color = get_hour_period_style(hour)
                
                # Determine the label based on time period
                if hour in peak_hours:
                    period_label = "🔴 Peak"
                elif hour in off_peak_hours:
                    period_label = "🟢 Off-Peak"
                else:
                    period_label = "🔵 Standard"
                
                # Display the period label with background color
                st.markdown(f"<div style='background-color: {bg_color}; padding: 5px; border-radius: 5px; margin-bottom: 5px; color: white;'><small>{period_label} Hour</small></div>", unsafe_allow_html=True)
                
                # Apply rate adjustments if enabled
                if auto_adjust_rates:
                    if hour in peak_hours:
                        default_rate = round(default_rate * peak_rate_multiplier, 1)
                    elif hour in off_peak_hours:
                        default_rate = round(default_rate * off_peak_rate_multiplier, 1)

                hourly_rates[hour] = st.number_input(
                    f"{hour:02d}:00",
                    min_value=0.0,
                    max_value=20.0,
                    value=round(default_rate, 1),
                    step=0.1,
                    key=f"hour_{hour}",
                    help=f"Rate for {hour:02d}:00 - {(hour+1):02d}:00"
                )

    # File upload section
    upload_col1, upload_col2, upload_col3 = st.columns([1,2,1])
    with upload_col2:
        st.markdown("""
            <div style='text-align: center; padding: 20px; border-radius: 10px; border: 2px dashed #3498db;'>
                <h4 style='color: #3498db;'>Upload your electricity consumption data</h4>
                <p style='color: #7f8c8d;'>File format: CSV with columns (timestamp, appliance, consumption_kwh)</p>
            </div>
        """, unsafe_allow_html=True)
        uploaded_file = st.file_uploader("", type="csv")

        if uploaded_file is not None:
            try:
                df = pd.read_csv(uploaded_file)
                
                # Validate CSV data
                is_valid, validation_errors = validate_csv_data(df)
                
                if not is_valid:
                    st.error("Invalid CSV file format:")
                    for error in validation_errors:
                        st.error(f"• {error}")
                    st.info("Please ensure your CSV file has the correct format with 'timestamp', 'appliance', and 'consumption_kwh' columns.")
                    return
                
                if st.button("Analyze Consumption", key="analyze_btn"):
                    with st.spinner("🔄 Analyzing your consumption patterns..."):
                        insights = process_uploaded_data(df, hourly_rates=hourly_rates)
                        
                        # Add progress animation
                        progress_bar = st.progress(0)
                        for i in range(100):
                            progress_bar.progress(i + 1)
                            time_module.sleep(0.01)  # Use time module with alias
                        progress_bar.empty()
                        
                        # Display summary cards
                        st.markdown("""
                        <div style='padding: 20px; border-radius: 10px; background: rgba(52, 152, 219, 0.1); margin-bottom: 20px;'>
                            <h2 style='color: #3498db; text-align: center;'>Analysis Summary</h2>
                        </div>
                        """, unsafe_allow_html=True)
                        
                        # Enhanced metrics display
                        col1, col2, col3 = st.columns(3)
                        with col1:
                            st.metric(
                                "Daily Savings Potential", 
                                f"₹{insights['total_potential_saving']:.2f}",
                                f"↓ {(insights['total_potential_saving']/insights['hourly_data'].sum().sum()*100):.1f}%",
                                delta_color="inverse"
                            )
                        with col2:
                            st.metric(
                                "Monthly Projection",
                                f"₹{insights['total_potential_saving'] * 30:.2f}",
                                "Based on current usage"
                            )
                        with col3:
                            peak_usage = insights['hourly_data'].loc[range(18, 22)].sum().sum()
                            st.metric(
                                "Peak Hour Usage",
                                f"{peak_usage:.1f} kWh",
                                "6 PM - 10 PM"
                            )

                        # Display enhanced consumption chart
                        st.markdown("### 📊 Consumption Analysis")
                        fig1 = create_detailed_consumption_chart(insights['hourly_data'], insights['optimized_consumption'])
                        st.plotly_chart(fig1, use_container_width=True, key="consumption_analysis")
                        
                        # Add download button for the consumption analysis
                        consumption_col1, consumption_col2 = st.columns([4, 1])
                        with consumption_col2:
                            # Create PDF data for consumption analysis upfront
                            try:
                                # Debug datetime import issue
                                from datetime import datetime as dt
                                # Debug colors issue
                                from reportlab.lib import colors as report_colors
                                
                                now = dt.now().strftime('%Y-%m-%d %H:%M')
                                
                                # Generate PDF for consumption analysis
                                buffer = io.BytesIO()
                                doc = SimpleDocTemplate(buffer, pagesize=landscape(letter))
                                story = []
                                styles = getSampleStyleSheet()
                                
                                # Title
                                title_style = ParagraphStyle(
                                    'CustomTitle',
                                    parent=styles['Heading1'],
                                    fontSize=18,
                                    alignment=1,  # Center alignment
                                    spaceAfter=20
                                )
                                story.append(Paragraph("Electricity Consumption Analysis", title_style))
                                story.append(Paragraph(f"Generated on: {now}", styles['Normal']))
                                story.append(Spacer(1, 20))
                                
                                # Hourly consumption table
                                story.append(Paragraph("Hourly Consumption Data (kWh)", styles['Heading2']))
                                
                                # Create a table with current and optimized hourly consumption
                                hour_data = [["Hour", "Current Usage", "Optimized Usage", "Difference", "Savings %"]]
                                
                                for hour in range(24):
                                    current = insights['hourly_data'].loc[hour].sum()
                                    optimized = insights['optimized_consumption'].loc[hour].sum()
                                    difference = current - optimized
                                    savings_percent = (difference / current * 100) if current > 0 else 0
                                    
                                    hour_data.append([
                                        f"{hour:02d}:00",
                                        f"{current:.3f}",
                                        f"{optimized:.3f}",
                                        f"{difference:.3f}",
                                        f"{savings_percent:.1f}%"
                                    ])
                                
                                # Add total row
                                total_current = insights['hourly_data'].values.sum()
                                total_optimized = insights['optimized_consumption'].values.sum()
                                total_difference = total_current - total_optimized
                                total_savings_percent = (total_difference / total_current * 100) if total_current > 0 else 0
                                
                                hour_data.append([
                                    "TOTAL",
                                    f"{total_current:.3f}",
                                    f"{total_optimized:.3f}",
                                    f"{total_difference:.3f}",
                                    f"{total_savings_percent:.1f}%"
                                ])
                                
                                # Style the table
                                consumption_table = Table(hour_data)
                                consumption_table.setStyle(TableStyle([
                                    ('BACKGROUND', (0, 0), (-1, 0), report_colors.grey),
                                    ('TEXTCOLOR', (0, 0), (-1, 0), report_colors.whitesmoke),
                                    ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                                    ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                                    ('BACKGROUND', (0, -1), (-1, -1), report_colors.lightgrey),
                                    ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
                                    ('GRID', (0, 0), (-1, -1), 1, report_colors.black)
                                ]))
                                story.append(consumption_table)
                                story.append(Spacer(1, 20))
                                
                                # Cost Analysis
                                story.append(Paragraph("Cost Analysis", styles['Heading2']))
                                
                                # Create a table showing hourly costs
                                cost_data = [["Time Period", "Current Cost (₹)", "Optimized Cost (₹)", "Savings (₹)"]]
                                
                                # Peak hours (6 PM - 10 PM)
                                peak_current_cost = sum(insights['hourly_data'].loc[hour].sum() * hourly_rates[hour] for hour in range(18, 22))
                                peak_optimized_cost = sum(insights['optimized_consumption'].loc[hour].sum() * hourly_rates[hour] for hour in range(18, 22))
                                peak_savings = peak_current_cost - peak_optimized_cost
                                
                                # Off-peak hours
                                off_peak_current_cost = sum(insights['hourly_data'].loc[hour].sum() * hourly_rates[hour] for hour in range(24) if hour < 18 or hour >= 22)
                                off_peak_optimized_cost = sum(insights['optimized_consumption'].loc[hour].sum() * hourly_rates[hour] for hour in range(24) if hour < 18 or hour >= 22)
                                off_peak_savings = off_peak_current_cost - off_peak_optimized_cost
                                
                                # Total
                                total_current_cost = peak_current_cost + off_peak_current_cost
                                total_optimized_cost = peak_optimized_cost + off_peak_optimized_cost
                                total_cost_savings = total_current_cost - total_optimized_cost
                                
                                # Add rows to cost data
                                cost_data.append(["Peak Hours (6 PM - 10 PM)", f"{peak_current_cost:.2f}", f"{peak_optimized_cost:.2f}", f"{peak_savings:.2f}"])
                                cost_data.append(["Off-Peak Hours", f"{off_peak_current_cost:.2f}", f"{off_peak_optimized_cost:.2f}", f"{off_peak_savings:.2f}"])
                                cost_data.append(["TOTAL", f"{total_current_cost:.2f}", f"{total_optimized_cost:.2f}", f"{total_cost_savings:.2f}"])
                                
                                # Style the cost table
                                cost_table = Table(cost_data)
                                cost_table.setStyle(TableStyle([
                                    ('BACKGROUND', (0, 0), (-1, 0), report_colors.grey),
                                    ('TEXTCOLOR', (0, 0), (-1, 0), report_colors.whitesmoke),
                                    ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                                    ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                                    ('BACKGROUND', (0, -1), (-1, -1), report_colors.lightgrey),
                                    ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
                                    ('GRID', (0, 0), (-1, -1), 1, report_colors.black)
                                ]))
                                story.append(cost_table)
                                story.append(Spacer(1, 20))
                                
                                # Savings projection
                                story.append(Paragraph("Savings Projection", styles['Heading2']))
                                savings_data = [
                                    ["Period", "Estimated Savings (₹)"],
                                    ["Daily", f"{total_cost_savings:.2f}"],
                                    ["Weekly", f"{total_cost_savings * 7:.2f}"],
                                    ["Monthly", f"{total_cost_savings * 30:.2f}"],
                                    ["Yearly", f"{total_cost_savings * 365:.2f}"]
                                ]
                                
                                savings_table = Table(savings_data)
                                savings_table.setStyle(TableStyle([
                                    ('BACKGROUND', (0, 0), (-1, 0), report_colors.grey),
                                    ('TEXTCOLOR', (0, 0), (-1, 0), report_colors.whitesmoke),
                                    ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                                    ('GRID', (0, 0), (-1, -1), 1, report_colors.black)
                                ]))
                                story.append(savings_table)
                                
                                # Build the PDF
                                doc.build(story)
                                buffer.seek(0)
                                
                                # Get PDF data
                                pdf_data = buffer.getvalue()
                                buffer.close()
                                
                                # Use st.download_button directly (without st.button wrapper)
                                st.download_button(
                                    label="📥 Download Analysis PDF",
                                    data=pdf_data,
                                    file_name=f"consumption_analysis_{now}.pdf",
                                    mime="application/pdf",
                                    key="pdf_download_consumption"
                                )
                            except Exception as e:
                                st.error(f"Error preparing PDF: {str(e)}")
                        
                        # After the consumption analysis chart
                        st.markdown("### 💰 Cost Analysis")
                        fig_price = create_price_analysis_chart(insights['hourly_data'], hourly_rates)
                        st.plotly_chart(fig_price, use_container_width=True, key="price_analysis")

                        # Add cost summary
                        total_daily_cost = sum(insights['hourly_data'].loc[hour].sum() * hourly_rates[hour] for hour in range(24))
                        peak_hours_cost = sum(insights['hourly_data'].loc[hour].sum() * hourly_rates[hour] for hour in range(18, 22))
                        off_peak_cost = total_daily_cost - peak_hours_cost

                        # Display cost metrics
                        cost_col1, cost_col2, cost_col3 = st.columns(3)
                        with cost_col1:
                            st.metric(
                                "Total Daily Cost",
                                f"₹{total_daily_cost:.2f}",
                                "Based on hourly rates"
                            )
                        with cost_col2:
                            st.metric(
                                "Peak Hours Cost (6 PM - 10 PM)",
                                f"₹{peak_hours_cost:.2f}",
                                f"{(peak_hours_cost/total_daily_cost*100):.1f}% of total"
                            )
                        with cost_col3:
                            st.metric(
                                "Off-Peak Hours Cost",
                                f"₹{off_peak_cost:.2f}",
                                f"{(off_peak_cost/total_daily_cost*100):.1f}% of total"
                            )
                        
                        # Add a bill comparison chart for all usage
                        optimized_daily_cost = sum(insights['optimized_consumption'].loc[hour].sum() * hourly_rates[hour] for hour in range(24))
                        bill_comparison = create_bill_comparison_chart(total_daily_cost, optimized_daily_cost)
                        st.plotly_chart(bill_comparison, use_container_width=True, key="main_bill_comparison")
                        
                        # Add appliance-wise breakdown
                        st.markdown("### 🔌 Appliance-wise Consumption")
                        fig2 = go.Figure(data=[
                            go.Pie(
                                labels=insights['daily_totals'].index,
                                values=insights['daily_totals'].values,
                                hole=.3,
                                marker_colors=['#3498db', '#2ecc71', '#e74c3c', '#f1c40f', '#9b59b6']
                            )
                        ])
                        fig2.update_layout(
                            title="Daily Consumption by Appliance",
                            paper_bgcolor='rgba(0,0,0,0)',
                            plot_bgcolor='rgba(0,0,0,0)',
                            font=dict(color='white')
                        )
                        st.plotly_chart(fig2, use_container_width=True, key="appliance_consumption")
                        
                        # Enhanced recommendations display
                        st.markdown("### ⚡ Smart Optimization Recommendations")
                        
                        # Calculate metrics for final conclusion
                        total_daily_savings = sum(rec['daily_potential_saving'] for rec in insights['appliance_recommendations'])
                        total_monthly_savings = total_daily_savings * 30
                        total_yearly_savings = total_daily_savings * 365
                        peak_hour_consumption = sum(insights['hourly_data'].loc[peak_hours].sum())
                        optimized_peak_consumption = sum(insights['optimized_consumption'].loc[peak_hours].sum())
                        peak_reduction_percent = ((peak_hour_consumption - optimized_peak_consumption) / peak_hour_consumption) * 100
                        significant_appliances = len([rec for rec in insights['appliance_recommendations'] if rec['daily_potential_saving'] > 0])
                        
                        # Info about excluded essential appliances with enhanced explanation
                        st.info("""
                        **Smart Comfort-Based Recommendations**
                        
                        Our system analyzes your usage patterns to provide recommendations that:
                        1. **Maintain your comfort level** while reducing costs
                        2. **Focus on high-impact, shiftable appliances** that affect your bill most
                        3. **Prioritize time-shifting** for flexible loads
                        4. **Consider device-specific characteristics** for optimal usage
                        5. **Balance energy savings with convenience**
                        
                        We focus on appliances that can be time-shifted effectively:
                        • Washing Machine
                        • Water Heater
                        • Air Conditioner
                        • Iron
                        • Microwave
                        • Mixer Grinder
                        
                        Non-shiftable loads like fans, TVs, and lights are excluded as they require 
                        immediate use and have minimal time-shifting benefits.
                        
                        **Key Benefits:**
                        • Targeted recommendations for shiftable loads
                        • Practical implementation steps
                        • Immediate and long-term savings
                        • Comfort-preserving strategies
                        • Device-specific efficiency tips
                        """)

                        # Add Final Conclusion section
                        st.markdown("### 📊 Final Results and Conclusion")

                        # Create final metrics display
                        final_col1, final_col2, final_col3 = st.columns(3)

                        with final_col1:
                            st.metric(
                                "Total Annual Savings Potential",
                                f"₹{total_yearly_savings:,.2f}",
                                f"₹{total_monthly_savings:,.2f} monthly"
                            )

                        with final_col2:
                            st.metric(
                                "Peak Hour Usage Reduction",
                                f"{peak_reduction_percent:.1f}%",
                                "During 6 PM - 10 PM"
                            )

                        with final_col3:
                            st.metric(
                                "Optimized Appliances",
                                f"{significant_appliances}",
                                "With savings potential"
                            )

                        # Add summary box
                        st.markdown(f"""
                        <div style='background-color: rgba(46, 204, 113, 0.1); padding: 20px; border-radius: 10px; margin: 20px 0;'>
                            <h4 style='color: #2ecc71;'>Summary of Optimization Impact</h4>
                            <p>By implementing the recommended time-shifting strategies:</p>
                            <ul>
                                <li>You can save up to <strong>₹{total_yearly_savings:,.2f}</strong> annually without compromising comfort</li>
                                <li>Peak hour consumption can be reduced by <strong>{peak_reduction_percent:.1f}%</strong></li>
                                <li>Monthly savings of <strong>₹{total_monthly_savings:,.2f}</strong> can be achieved</li>
                                <li>{significant_appliances} appliances have been identified for optimization</li>
                            </ul>
                            <p><strong>Next Steps:</strong></p>
                            <ol>
                                <li>Start with the highest-impact appliances first</li>
                                <li>Use timers and scheduling features when available</li>
                                <li>Monitor your savings through your electricity bills</li>
                                <li>Adjust usage patterns gradually for sustainable changes</li>
                            </ol>
                        </div>
                        """, unsafe_allow_html=True)

                        # Add environmental impact if savings are significant
                        if total_yearly_savings > 1000:
                            # Estimate CO2 reduction (assuming 0.82 kg CO2 per kWh)
                            kwh_saved = total_yearly_savings / 8  # Assuming ₹8 per kWh
                            co2_saved = kwh_saved * 0.82
                            trees_equivalent = co2_saved / 20  # One tree absorbs approximately 20 kg CO2 per year

                            st.markdown("""
                            <div style='background-color: rgba(52, 152, 219, 0.1); padding: 20px; border-radius: 10px; margin: 20px 0;'>
                                <h4 style='color: #3498db;'>Environmental Impact</h4>
                            """, unsafe_allow_html=True)

                            env_col1, env_col2 = st.columns(2)

                            with env_col1:
                                st.metric(
                                    "Annual CO₂ Reduction",
                                    f"{co2_saved:,.1f} kg",
                                    "Reduced carbon footprint"
                                )

                            with env_col2:
                                st.metric(
                                    "Equivalent to Trees Planted",
                                    f"{trees_equivalent:.0f} trees",
                                    "Annual CO₂ absorption"
                                )

                            st.markdown("""
                            </div>
                            """, unsafe_allow_html=True)

                        # Add final call to action
                        st.success("""
                        **Ready to Start Saving?**
                        
                        Begin implementing these recommendations today to see immediate savings on your electricity bill.
                        Remember, even small changes in usage patterns can lead to significant savings over time.
                        """)

                        # PDF Report Generation
                        st.markdown("---")
                        st.markdown("### 📑 Download Analysis Report")

                        # Create the full report PDF upfront
                        try:
                            # Debug datetime issue
                            from datetime import datetime as dt
                            # Debug colors issue
                            from reportlab.lib import colors as report_colors
                            
                            now = dt.now().strftime('%Y-%m-%d %H:%M')
                            
                            # Create PDF in memory
                            buffer = io.BytesIO()
                            doc = SimpleDocTemplate(buffer, pagesize=letter)
                            elements = []
                            styles = getSampleStyleSheet()
                            
                            # Title
                            elements.append(Paragraph("Smart Energy Analysis Report", styles['Heading1']))
                            elements.append(Paragraph(f"Generated on: {now}", styles['Normal']))
                            elements.append(Spacer(1, 20))
                            
                            # Summary Table
                            elements.append(Paragraph("Summary of Findings", styles['Heading2']))
                            summary_data = [
                                ["Metric", "Value"],
                                ["Annual Savings Potential", f"₹{total_yearly_savings:,.2f}"],
                                ["Monthly Savings", f"₹{total_monthly_savings:,.2f}"],
                                ["Peak Hour Reduction", f"{peak_reduction_percent:.1f}%"],
                                ["Optimized Appliances", str(significant_appliances)]
                            ]
                            
                            table = Table(summary_data, colWidths=[200, 200])
                            table.setStyle(TableStyle([
                                ('BACKGROUND', (0, 0), (-1, 0), report_colors.grey),
                                ('TEXTCOLOR', (0, 0), (-1, 0), report_colors.whitesmoke),
                                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                                ('GRID', (0, 0), (-1, -1), 1, report_colors.black)
                            ]))
                            elements.append(table)
                            elements.append(Spacer(1, 20))
                            
                            # Recommendations
                            elements.append(Paragraph("Appliance-Specific Recommendations", styles['Heading2']))
                            for rec in insights['appliance_recommendations']:
                                elements.append(Paragraph(f"• {rec['appliance']}", styles['Heading3']))
                                elements.append(Paragraph(f"Current Consumption: {rec['current_consumption']:.2f} kWh", styles['Normal']))
                                elements.append(Paragraph(f"Potential Savings: ₹{rec['daily_potential_saving']:.2f} per day", styles['Normal']))
                                if 'specific_tips' in rec:
                                    for tip in rec['specific_tips']:
                                        elements.append(Paragraph(f"- {tip}", styles['Normal']))
                                elements.append(Spacer(1, 10))
                            
                            # Environmental Impact
                            if total_yearly_savings > 1000:
                                co2_saved = total_yearly_savings * 0.85
                                trees_equivalent = co2_saved / 20
                                elements.append(Paragraph("Environmental Impact", styles['Heading2']))
                                elements.append(Paragraph(f"• CO₂ Reduction: {co2_saved:,.1f} kg/year", styles['Normal']))
                                elements.append(Paragraph(f"• Equivalent to {trees_equivalent:.0f} trees planted", styles['Normal']))
                            
                            # Build PDF
                            doc.build(elements)
                            
                            # Get PDF data
                            pdf_data = buffer.getvalue()
                            buffer.close()
                            
                            # Use st.download_button directly
                            st.download_button(
                                label="📥 Download Complete Analysis Report",
                                data=pdf_data,
                                file_name=f"energy_analysis_report_{now}.pdf",
                                mime="application/pdf",
                                key="full_report_download"
                            )
                        except Exception as e:
                            st.error(f"Error preparing full report: {str(e)}")

                        # Add comfort priority level feature
                        comfort_priority = {
                            'Air Conditioner': {'level': 'High', 'icon': '😊', 'color': '#e74c3c'},
                            'Refrigerator': {'level': 'Essential', 'icon': '⚠️', 'color': '#e67e22'},
                            'Washing Machine': {'level': 'Flexible', 'icon': '✅', 'color': '#2ecc71'},
                            'Water Heater': {'level': 'High', 'icon': '😊', 'color': '#e74c3c'},
                            'Television': {'level': 'Medium', 'icon': '👍', 'color': '#3498db'},
                            'Computer': {'level': 'Medium', 'icon': '👍', 'color': '#3498db'},
                            'Microwave': {'level': 'Flexible', 'icon': '✅', 'color': '#2ecc71'},
                            'Dishwasher': {'level': 'Flexible', 'icon': '✅', 'color': '#2ecc71'},
                            'Oven': {'level': 'Medium', 'icon': '👍', 'color': '#3498db'},
                            'Electric Vehicle': {'level': 'Flexible', 'icon': '✅', 'color': '#2ecc71'},
                            'Air Purifier': {'level': 'High', 'icon': '😊', 'color': '#e74c3c'}
                        }
                        
                        # Add time preferences by appliance
                        time_preferences = {
                            'Air Conditioner': {
                                'preferred': [21, 22, 23, 0, 1, 2, 3, 4, 5, 6],
                                'acceptable': [8, 9, 10, 11, 12, 13, 14, 15],
                                'avoid': [17, 18, 19, 20]
                            },
                            'Washing Machine': {
                                'preferred': [9, 10, 11, 12, 13, 14, 22, 23, 0, 1, 2, 3, 4],
                                'acceptable': [5, 6, 7, 8, 15, 16],
                                'avoid': [17, 18, 19, 20, 21]
                            },
                            'Water Heater': {
                                'preferred': [4, 5, 6, 7, 22, 23, 0, 1, 2, 3],
                                'acceptable': [8, 9, 10, 11, 12, 13, 14, 15],
                                'avoid': [16, 17, 18, 19, 20, 21]
                            }
                        }
                        
                        appliance_icons = {
                            'Air Conditioner': '❄️',
                            'Refrigerator': '🧊',
                            'Washing Machine': '🧺',
                            'Water Heater': '🔥',
                            'Television': '📺',
                            'Computer': '💻',
                            'Microwave': '🍲',
                            'Dishwasher': '🍽️',
                            'Oven': '🔥',
                            'Electric Vehicle': '🚗',
                            'Solar Panel': '☀️',
                            'Air Purifier': '💨'
                        }
                        
                        # Define appliances to exclude from the recommendation display
                        excluded_appliances = ['Fan', 'Iron', 'Light Bulbs', 'Light Bulb', 'Lighting', 'Ceiling Fan', 'Table Fan']
                        
                        # Filter out excluded appliances before display
                        filtered_recommendations = []
                        for rec in insights['appliance_recommendations']:
                            if not any(excluded.lower() in rec['appliance'].lower() for excluded in excluded_appliances):
                                filtered_recommendations.append(rec)
                        
                        # Sort by impact potential (combination of cost saving and comfort flexibility)
                        def calculate_impact_score(rec):
                            appliance = rec['appliance']
                            comfort_level = comfort_priority.get(appliance, {'level': 'Medium'})['level']
                            
                            # Higher score for flexible appliances with high saving potential
                            if comfort_level == 'Flexible':
                                multiplier = 1.5
                            elif comfort_level == 'Medium':
                                multiplier = 1.0
                            elif comfort_level == 'High':
                                multiplier = 0.8
                            else:  # Essential
                                multiplier = 0.5
                                
                            return rec['daily_potential_saving'] * multiplier
                        
                        # Sort recommendations by impact score
                        filtered_recommendations.sort(key=calculate_impact_score, reverse=True)
                        
                        # Display only the filtered recommendations
                        for idx, rec in enumerate(filtered_recommendations):
                            appliance = rec['appliance']
                            comfort_info = comfort_priority.get(appliance, {'level': 'Medium', 'icon': '👍', 'color': '#3498db'})
                            
                            # Create dynamic header based on comfort priority
                            header_text = f"{appliance_icons.get(appliance, '🔌')} {appliance} - {comfort_info['icon']} {comfort_info['level']} Comfort Priority"
                            
                            with st.expander(header_text, expanded=(idx == 0)):
                                # Create a user profile section
                                st.markdown(f"""
                                <div style='background-color: rgba(52, 152, 219, 0.1); 
                                           padding: 15px; border-radius: 10px; margin-bottom: 20px;'>
                                    <h4 style='color: #3498db;'>Your {appliance} Usage Profile</h4>
                                </div>
                                """, unsafe_allow_html=True)
                                
                                profile_col1, profile_col2 = st.columns(2)
                                
                                with profile_col1:
                                    st.subheader("Current Usage Metrics")
                                    st.write(f"Daily Usage: {rec['current_consumption']:.2f} kWh")
                                    st.write(f"Daily Cost: ₹{rec['current_consumption'] * 8:.2f}")
                                    st.write(f"Peak Hour Usage: {rec['current_consumption'] * 0.4:.2f} kWh")
                                    
                                    # Add usage classification
                                    if rec['current_consumption'] > 3.0:
                                        usage_class = "Heavy User"
                                        usage_color = "#e74c3c"
                                    elif rec['current_consumption'] > 1.0:
                                        usage_class = "Moderate User"
                                        usage_color = "#f39c12"
                                    else:
                                        usage_class = "Light User"
                                        usage_color = "#2ecc71"
                                        
                                    st.markdown(f"""
                                    <div style='background-color: {usage_color}; color: white; 
                                               padding: 5px 10px; border-radius: 5px; display: inline-block;'>
                                        {usage_class}
                                    </div>
                                    """, unsafe_allow_html=True)
                                
                                with profile_col2:
                                    st.subheader("Optimization Potential")
                                    st.write(f"Recommended Usage: {rec['optimal_consumption']:.2f} kWh")
                                    st.write(f"Potential Cost: ₹{rec['optimal_consumption'] * 8:.2f}")
                                    st.write(f"Daily Saving: ₹{rec['daily_potential_saving']:.2f}")
                                    
                                    # Add comfort impact indicator
                                    if comfort_info['level'] == 'Flexible':
                                        comfort_impact = "No Impact on Comfort"
                                        impact_color = "#2ecc71"
                                    elif comfort_info['level'] == 'Medium':
                                        comfort_impact = "Minimal Impact on Comfort"
                                        impact_color = "#3498db"
                                    else:
                                        comfort_impact = "Comfort-Preserving Options Only"
                                        impact_color = "#e74c3c"
                                        
                                    st.markdown(f"""
                                    <div style='background-color: {impact_color}; color: white; 
                                               padding: 5px 10px; border-radius: 5px; display: inline-block;'>
                                        {comfort_impact}
                                    </div>
                                    """, unsafe_allow_html=True)
                                
                                # Add a personalized strategy section
                                if comfort_info['level'] in ['Flexible', 'Medium']:
                                    strategy_title = "Recommended: Time-Shifting Strategy"
                                    strategy_description = f"Shift your {appliance} usage from peak to off-peak hours without reducing total usage."
                                else:
                                    strategy_title = "Recommended: Comfort-Preserving Strategy"
                                    strategy_description = f"Optimize your {appliance} usage while maintaining your comfort preferences."
                                
                                st.markdown(f"""
                                <div style='background-color: rgba(46, 204, 113, 0.1); 
                                           padding: 15px; border-radius: 10px; margin: 20px 0;'>
                                    <h4 style='color: #2ecc71;'>{strategy_title}</h4>
                                    <p>{strategy_description}</p>
                                </div>
                                """, unsafe_allow_html=True)
                                
                                # Add a usage pattern visualization to make it more intuitive
                                usage_data = {"Hour": [], "Current Pattern": [], "Recommended Pattern": []}
                                for hour in range(24):
                                    usage_data["Hour"].append(f"{hour:02d}:00")
                                    
                                    # Generate a realistic usage pattern based on appliance type
                                    current_value = 0
                                    recommended_value = 0
                                    
                                    # Use time preferences if available, otherwise default to peak/off-peak hours
                                    appliance_preferences = time_preferences.get(appliance, {
                                        'preferred': off_peak_hours,
                                        'acceptable': standard_hours,
                                        'avoid': peak_hours
                                    })
                                    
                                    # Peak hours typically have higher usage in current pattern
                                    if hour in appliance_preferences['avoid']:
                                        current_value = rec['current_consumption'] * 0.1  # 40% of usage spread across avoid hours
                                        recommended_value = rec['current_consumption'] * 0.02  # Minimal usage during avoid hours
                                    # Shift usage to preferred hours in recommended pattern
                                    elif hour in appliance_preferences['preferred']:
                                        current_value = rec['current_consumption'] * 0.02  # Lower usage during preferred hours
                                        recommended_value = rec['current_consumption'] * 0.08  # Increased usage during preferred hours
                                    else:
                                        # Acceptable hours have moderate usage in both patterns
                                        current_value = rec['current_consumption'] * 0.04
                                        recommended_value = rec['current_consumption'] * 0.04  # No change
                                        
                                    usage_data["Current Pattern"].append(current_value)
                                    usage_data["Recommended Pattern"].append(recommended_value)
                                
                                # Convert to DataFrame for plotting
                                usage_df = pd.DataFrame(usage_data)
                                
                                # Create a simple bar chart of the usage patterns
                                fig = go.Figure()
                                fig.add_trace(go.Bar(
                                    x=usage_df["Hour"], 
                                    y=usage_df["Current Pattern"],
                                    name="Current Usage Pattern",
                                    marker_color='#e74c3c'
                                ))
                                fig.add_trace(go.Bar(
                                    x=usage_df["Hour"], 
                                    y=usage_df["Recommended Pattern"],
                                    name="Recommended Pattern",
                                    marker_color='#2ecc71'
                                ))
                                
                                # Add time period highlights
                                for hour in peak_hours:
                                    hour_str = f"{hour:02d}:00"
                                    if hour_str in usage_df["Hour"].values:
                                        fig.add_vline(
                                            x=usage_df[usage_df["Hour"]==hour_str].index[0],
                                            line_width=2,
                                            line_dash="dash",
                                            line_color="rgba(231, 76, 60, 0.5)"
                                        )
                                
                                fig.update_layout(
                                    title=f"{appliance} Usage Pattern Comparison",
                                    xaxis_title="Hour of Day",
                                    yaxis_title="Energy Usage (kWh)",
                                    barmode='group',
                                    legend=dict(
                                        orientation="h",
                                        yanchor="bottom",
                                        y=1.02,
                                        xanchor="center",
                                        x=0.5
                                    ),
                                    plot_bgcolor='rgba(0,0,0,0)',
                                    height=350
                                )
                                
                                # Add annotations for time periods
                                if appliance in time_preferences:
                                    preferred_hour = time_preferences[appliance]['preferred'][0]
                                    avoid_hour = time_preferences[appliance]['avoid'][0]
                                    
                                    fig.add_annotation(
                                        x=preferred_hour,
                                        y=max(usage_df["Recommended Pattern"]) * 1.1,
                                        text="Best Usage Hours",
                                        showarrow=True,
                                        arrowhead=1,
                                        ax=0,
                                        ay=-40,
                                        font=dict(color="#2ecc71")
                                    )
                                    
                                    fig.add_annotation(
                                        x=avoid_hour,
                                        y=max(usage_df["Current Pattern"]) * 1.1,
                                        text="Hours to Avoid",
                                        showarrow=True,
                                        arrowhead=1,
                                        ax=0,
                                        ay=-40,
                                        font=dict(color="#e74c3c")
                                    )
                                else:
                                    fig.add_annotation(
                                        x=19,  # Middle of peak hours
                                        y=max(usage_df["Current Pattern"]) * 1.1,
                                        text="Peak Hours",
                                        showarrow=True,
                                        arrowhead=1,
                                        ax=0,
                                        ay=-40,
                                        font=dict(color="#e74c3c")
                                    )
                                    
                                    fig.add_annotation(
                                        x=2,  # Early off-peak hours
                                        y=max(usage_df["Recommended Pattern"]) * 1.1,
                                        text="Off-Peak Hours",
                                        showarrow=True,
                                        arrowhead=1,
                                        ax=0,
                                        ay=-40,
                                        font=dict(color="#2ecc71")
                                    )
                                
                                st.plotly_chart(fig, use_container_width=True, key=f"usage_pattern_{appliance}_{idx}")
                                
                                # Add download button for this specific analysis
                                download_col1, download_col2 = st.columns([3, 1])
                                with download_col2:
                                    # Create PDF data upfront for this appliance
                                    try:
                                        # Calculate rates needed for PDF
                                        peak_rate_avg = sum(hourly_rates[hour] for hour in peak_hours) / len(peak_hours)
                                        off_peak_rate_avg = sum(hourly_rates[hour] for hour in off_peak_hours) / len(off_peak_hours)
                                        peak_cost = rec['current_consumption'] * 0.4 * peak_rate_avg
                                        off_peak_cost = rec['current_consumption'] * 0.4 * off_peak_rate_avg
                                        potential_daily_saving = peak_cost - off_peak_cost
                                        annual_saving = potential_daily_saving * 365
                                        percent_reduction = ((peak_rate_avg - off_peak_rate_avg) / peak_rate_avg) * 100
                                        
                                        # Define hourly recommendations dict that will be used in the PDF
                                        if appliance in time_preferences:
                                            hourly_recs = {
                                                'Preferred Hours': [f"{h:02d}:00" for h in time_preferences[appliance]['preferred']],
                                                'Acceptable Hours': [f"{h:02d}:00" for h in time_preferences[appliance]['acceptable']],
                                                'Hours to Avoid': [f"{h:02d}:00" for h in time_preferences[appliance]['avoid']]
                                            }
                                        else:
                                            hourly_recs = {
                                                'Preferred Hours': [f"{h:02d}:00" for h in off_peak_hours],
                                                'Acceptable Hours': [f"{h:02d}:00" for h in standard_hours],
                                                'Hours to Avoid': [f"{h:02d}:00" for h in peak_hours]
                                            }
                                        
                                        # Import modules inside function scope
                                        from datetime import datetime as dt
                                        from reportlab.lib import colors as report_colors
                                        
                                        now = dt.now().strftime('%Y-%m-%d %H:%M')
                                        
                                        # Generate PDF for this specific pattern analysis
                                        buffer = io.BytesIO()
                                        doc = SimpleDocTemplate(buffer, pagesize=letter)
                                        story = []
                                        styles = getSampleStyleSheet()
                                        
                                        # Title and date
                                        story.append(Paragraph(f"{appliance} Usage Pattern Analysis", styles['Heading1']))
                                        story.append(Paragraph(f"Generated on: {now}", styles['Normal']))
                                        story.append(Spacer(1, 20))
                                        
                                        # Usage pattern information
                                        story.append(Paragraph("Hourly Usage Patterns", styles['Heading2']))
                                        
                                        # Create a table with the hourly data
                                        hour_data = [["Hour", "Current Pattern (kWh)", "Recommended Pattern (kWh)"]]
                                        for i, hour in enumerate(usage_df["Hour"]):
                                            hour_data.append([
                                                hour, 
                                                f"{usage_df['Current Pattern'][i]:.3f}", 
                                                f"{usage_df['Recommended Pattern'][i]:.3f}"
                                            ])
                                        
                                        table = Table(hour_data)
                                        table.setStyle(TableStyle([
                                            ('BACKGROUND', (0, 0), (-1, 0), report_colors.grey),
                                            ('TEXTCOLOR', (0, 0), (-1, 0), report_colors.whitesmoke),
                                            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                                            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                                            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                                            ('GRID', (0, 0), (-1, -1), 1, report_colors.black)
                                        ]))
                                        story.append(table)
                                        story.append(Spacer(1, 20))
                                        
                                        # Time recommendations
                                        story.append(Paragraph("Time Recommendations", styles['Heading2']))
                                        
                                        # Preferred times
                                        story.append(Paragraph("Best Times to Use:", styles['Heading3']))
                                        preferred_text = ", ".join(hourly_recs['Preferred Hours'][:8])
                                        if len(hourly_recs['Preferred Hours']) > 8:
                                            preferred_text += f", and {len(hourly_recs['Preferred Hours']) - 8} more hours"
                                        story.append(Paragraph(preferred_text, styles['Normal']))
                                        story.append(Spacer(1, 10))
                                        
                                        # Times to avoid
                                        story.append(Paragraph("Times to Avoid:", styles['Heading3']))
                                        avoid_text = ", ".join(hourly_recs['Hours to Avoid'])
                                        story.append(Paragraph(avoid_text, styles['Normal']))
                                        story.append(Spacer(1, 20))
                                        
                                        # Cost comparison
                                        story.append(Paragraph("Cost Comparison", styles['Heading2']))
                                        cost_data = [
                                            ["", "Peak Hours", "Off-Peak Hours"],
                                            ["Rate per Unit", f"₹{peak_rate_avg:.2f}", f"₹{off_peak_rate_avg:.2f}"],
                                            ["Usage (kWh)", f"{rec['current_consumption'] * 0.4:.2f}", f"{rec['current_consumption'] * 0.4:.2f}"],
                                            ["Cost per Day", f"₹{peak_cost:.2f}", f"₹{off_peak_cost:.2f}"]
                                        ]
                                        
                                        cost_table = Table(cost_data)
                                        cost_table.setStyle(TableStyle([
                                            ('BACKGROUND', (0, 0), (-1, 0), report_colors.grey),
                                            ('TEXTCOLOR', (0, 0), (-1, 0), report_colors.whitesmoke),
                                            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                                            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                                            ('GRID', (0, 0), (-1, -1), 1, report_colors.black)
                                        ]))
                                        story.append(cost_table)
                                        story.append(Spacer(1, 20))
                                        
                                        # Savings summary
                                        story.append(Paragraph("Savings Summary", styles['Heading2']))
                                        story.append(Paragraph(f"Daily Savings: ₹{potential_daily_saving:.2f}", styles['Normal']))
                                        story.append(Paragraph(f"Monthly Savings: ₹{potential_daily_saving * 30:.2f}", styles['Normal']))
                                        story.append(Paragraph(f"Annual Savings: ₹{annual_saving:.2f}", styles['Normal']))
                                        story.append(Paragraph(f"Rate Reduction: {percent_reduction:.1f}%", styles['Normal']))
                                        
                                        # Build PDF
                                        doc.build(story)
                                        buffer.seek(0)
                                        
                                        # Get PDF data
                                        pdf_data = buffer.getvalue()
                                        buffer.close()
                                        
                                        # Use st.download_button directly
                                        st.download_button(
                                            label="📥 Download Pattern PDF",
                                            data=pdf_data,
                                            file_name=f"{appliance}_usage_analysis_{now}.pdf",
                                            mime="application/pdf",
                                            key=f"pdf_download_{appliance}_{idx}"
                                        )
                                    except Exception as e:
                                        st.error(f"Error preparing PDF: {str(e)}")
                                
                                # Calculate the peak and off-peak costs for this appliance
                                peak_rate_avg = sum(hourly_rates[hour] for hour in peak_hours) / len(peak_hours)
                                off_peak_rate_avg = sum(hourly_rates[hour] for hour in off_peak_hours) / len(off_peak_hours)
                                peak_cost = rec['current_consumption'] * 0.4 * peak_rate_avg  # Assuming 40% usage during peak hours
                                off_peak_cost = rec['current_consumption'] * 0.4 * off_peak_rate_avg
                                potential_daily_saving = peak_cost - off_peak_cost
                                annual_saving = potential_daily_saving * 365
                                percent_reduction = ((peak_rate_avg - off_peak_rate_avg) / peak_rate_avg) * 100
                                
                                # Create personalized hourly recommendations
                                st.subheader("Personalized Hourly Recommendations")
                                
                                # Define hourly_recs for display in UI
                                if appliance in time_preferences:
                                    hourly_recs = {
                                        'Preferred Hours': [f"{h:02d}:00" for h in time_preferences[appliance]['preferred']],
                                        'Acceptable Hours': [f"{h:02d}:00" for h in time_preferences[appliance]['acceptable']],
                                        'Hours to Avoid': [f"{h:02d}:00" for h in time_preferences[appliance]['avoid']]
                                    }
                                else:
                                    hourly_recs = {
                                        'Preferred Hours': [f"{h:02d}:00" for h in off_peak_hours],
                                        'Acceptable Hours': [f"{h:02d}:00" for h in standard_hours],
                                        'Hours to Avoid': [f"{h:02d}:00" for h in peak_hours]
                                    }
                                
                                hour_col1, hour_col2, hour_col3 = st.columns(3)
                                
                                with hour_col1:
                                    st.markdown(f"""
                                    <div style='background-color: rgba(46, 204, 113, 0.1); padding: 10px; border-radius: 5px;'>
                                        <h5 style='color: #2ecc71;'>✅ Best Times to Use</h5>
                                    </div>
                                    """, unsafe_allow_html=True)
                                    
                                    for hour in hourly_recs['Preferred Hours'][:8]:  # Limit display
                                        st.write(f"• {hour}")
                                    
                                    if len(hourly_recs['Preferred Hours']) > 8:
                                        st.write(f"• ... and {len(hourly_recs['Preferred Hours']) - 8} more hours")
                                
                                with hour_col2:
                                    st.markdown(f"""
                                    <div style='background-color: rgba(52, 152, 219, 0.1); padding: 10px; border-radius: 5px;'>
                                        <h5 style='color: #3498db;'>👍 Acceptable Times</h5>
                                    </div>
                                    """, unsafe_allow_html=True)
                                    
                                    for hour in hourly_recs['Acceptable Hours'][:8]:  # Limit display
                                        st.write(f"• {hour}")
                                    
                                    if len(hourly_recs['Acceptable Hours']) > 8:
                                        st.write(f"• ... and {len(hourly_recs['Acceptable Hours']) - 8} more hours")
                                
                                with hour_col3:
                                    st.markdown(f"""
                                    <div style='background-color: rgba(231, 76, 60, 0.1); padding: 10px; border-radius: 5px;'>
                                        <h5 style='color: #e74c3c;'>❌ Times to Avoid</h5>
                                    </div>
                                    """, unsafe_allow_html=True)
                                    
                                    for hour in hourly_recs['Hours to Avoid']:
                                        st.write(f"• {hour}")
                                
                                # Show direct cost comparison for this appliance
                                st.subheader("Cost Comparison")
                                comparison_col1, comparison_col2 = st.columns(2)
                                
                                with comparison_col1:
                                    st.error(f"**PEAK HOURS USAGE**")
                                    st.write(f"⚡ Rate: ₹{peak_rate_avg:.2f} per unit")
                                    st.write(f"💰 Cost: ₹{peak_cost:.2f} per day")
                                    st.write(f"📊 {rec['current_consumption'] * 0.4:.2f} kWh usage")
                                
                                with comparison_col2:
                                    st.success(f"**OFF-PEAK HOURS USAGE**")
                                    st.write(f"⚡ Rate: ₹{off_peak_rate_avg:.2f} per unit")
                                    st.write(f"💰 Cost: ₹{off_peak_cost:.2f} per day")
                                    st.write(f"📊 Same {rec['current_consumption'] * 0.4:.2f} kWh usage")
                                
                                # Clearly show the savings with enhanced visualization
                                cost_comparison = {
                                    "Category": ["Peak Hours Usage", "Off-Peak Hours Usage"],
                                    "Current Cost": [peak_cost, off_peak_cost],
                                    "Shifted Cost": [0, peak_cost + off_peak_cost]  # All usage shifted to off-peak
                                }
                                cost_df = pd.DataFrame(cost_comparison)
                                
                                fig2 = go.Figure()
                                fig2.add_trace(go.Bar(
                                    x=cost_df["Category"],
                                    y=cost_df["Current Cost"],
                                    name="Current Cost Pattern",
                                    marker_color='#e74c3c'
                                ))
                                fig2.add_trace(go.Bar(
                                    x=cost_df["Category"],
                                    y=cost_df["Shifted Cost"],
                                    name="Cost After Shifting",
                                    marker_color='#2ecc71'
                                ))
                                
                                fig2.update_layout(
                                    title="Cost Comparison: Before vs After Time-Shifting",
                                    yaxis_title="Cost (₹)",
                                    barmode='group',
                                    plot_bgcolor='rgba(0,0,0,0)',
                                    height=300
                                )
                                
                                # Add annotation for savings
                                fig2.add_annotation(
                                    x=1,
                                    y=cost_df["Shifted Cost"].max() * 1.1,
                                    text=f"Daily Savings: ₹{potential_daily_saving:.2f}",
                                    showarrow=False,
                                    font=dict(size=14, color="#2ecc71")
                                )
                                
                                st.plotly_chart(fig2, use_container_width=True, key=f"cost_comparison_{appliance}_{idx}")
                                
                                # Clearly show the savings
                                st.info(f"""
                                **SAVINGS BY TIME-SHIFTING:**
                                
                                • Rate difference: **{percent_reduction:.1f}% lower** during off-peak hours
                                • Daily savings: **₹{potential_daily_saving:.2f}** (using same amount of electricity)
                                • Monthly savings: **₹{potential_daily_saving * 30:.2f}**
                                • Annual savings: **₹{annual_saving:.2f}**
                                
                                You maintain full comfort while saving money - same usage, just different times!
                                """)
                                
                                # Create appliance-specific implementation plans
                                st.subheader("Personalized Implementation Plan")
                                
                                # Define implementation steps based on appliance type
                                implementation_steps = []
                                
                                if appliance == 'Air Conditioner':
                                    implementation_steps = [
                                        "Pre-cool your room before peak hours (4-5 PM) then use the timer to cycle on/off",
                                        "Use sleep mode at night to optimize energy consumption",
                                        "Consider using a fan alongside AC to maintain comfort at higher temperature settings",
                                        "Raise temperature setting by 1°C when in peak hours (each degree saves ~6% energy)"
                                    ]
                                elif appliance == 'Washing Machine':
                                    implementation_steps = [
                                        "Schedule washing loads for early morning (5-8 AM) or late night (after 10 PM)",
                                        "Use delay start function to automatically run during off-peak hours",
                                        "Batch multiple small loads into fewer full loads for better efficiency",
                                        "Use cold water when possible to reduce heating energy"
                                    ]
                                elif appliance == 'Water Heater':
                                    implementation_steps = [
                                        "Heat water during off-peak hours and use insulated tanks to maintain temperature",
                                        "Install a timer to automatically operate during lowest-rate hours",
                                        "Reduce temperature setting by 2-3°C for immediate savings (still comfortable)",
                                        "Consider insulating hot water pipes to reduce heat loss"
                                    ]
                                elif 'Television' in appliance or 'TV' in appliance:
                                    implementation_steps = [
                                        "Use power-saving mode when watching during peak hours",
                                        "Reduce brightness setting during evening hours",
                                        "Avoid leaving TV on standby - use smart power strips to eliminate phantom load",
                                        "Schedule recording of shows rather than watching live during peak hours"
                                    ]
                                else:
                                    implementation_steps = [
                                        f"Shift {appliance} usage to off-peak hours (10 PM - 6 AM) or standard hours (10 AM - 4 PM)",
                                        "Use timer functions or smart plugs to automate usage during preferred hours",
                                        "Consider using energy-saving mode when operating during peak hours",
                                        "Batch usage into fewer, longer sessions rather than multiple short uses"
                                    ]
                                
                                # Display implementation steps
                                for i, step in enumerate(implementation_steps, 1):
                                    st.markdown(f"""
                                    <div style='background-color: rgba(52, 152, 219, 0.05); 
                                               padding: 10px; border-radius: 5px; margin: 5px 0;
                                               border-left: 3px solid #3498db;'>
                                        <b>Step {i}:</b> {step}
                                    </div>
                                    """, unsafe_allow_html=True)
                                
                                # Add expected outcome and comfort impact
                                st.subheader("Expected Outcome")
                                
                                outcome_col1, outcome_col2 = st.columns(2)
                                
                                with outcome_col1:
                                    st.metric(
                                        "Monthly Bill Reduction", 
                                        f"₹{potential_daily_saving * 30:.2f}", 
                                        f"{percent_reduction:.1f}% lower rates"
                                    )
                                
                                with outcome_col2:
                                    # Customize comfort impact based on appliance
                                    if comfort_info['level'] == 'Flexible':
                                        comfort_change = "No Change"
                                        comfort_delta = "Same comfort level"
                                    elif comfort_info['level'] == 'Medium':
                                        comfort_change = "Minimal Adjustment"
                                        comfort_delta = "Slightly different timing"
                                    else:
                                        comfort_change = "Comfort Preserved"
                                        comfort_delta = "Different timing only"
                                    
                                    st.metric(
                                        "Comfort Impact",
                                        comfort_change,
                                        comfort_delta
                                    )
                                
                                # Add projected savings visualization over time
                                st.subheader("Projected Savings Over Time")
                                
                                # Create data for projected savings visualization
                                # Calculate monthly and yearly projections
                                current_monthly_cost = rec['current_consumption'] * 8 * 30
                                optimized_monthly_cost = rec['optimal_consumption'] * 8 * 30
                                monthly_saving = current_monthly_cost - optimized_monthly_cost
                                
                                # Create 12-month projection for single appliance
                                months = list(range(1, 13))
                                current_costs = [current_monthly_cost] * 12
                                optimized_costs = [optimized_monthly_cost] * 12
                                cumulative_savings = [monthly_saving * i for i in months]
                                
                                # Create a figure with secondary y-axis
                                fig3 = go.Figure()
                                
                                # Add current costs
                                fig3.add_trace(go.Bar(
                                    x=months,
                                    y=current_costs,
                                    name='Current Cost',
                                    marker_color='#e74c3c'
                                ))
                                
                                # Add optimized costs
                                fig3.add_trace(go.Bar(
                                    x=months,
                                    y=optimized_costs,
                                    name='Cost After Optimization',
                                    marker_color='#2ecc71'
                                ))
                                
                                # Add cumulative savings line
                                fig3.add_trace(go.Scatter(
                                    x=months,
                                    y=cumulative_savings,
                                    name='Cumulative Savings',
                                    mode='lines+markers',
                                    line=dict(color='#3498db', width=3),
                                    marker=dict(size=8),
                                    yaxis='y2'
                                ))
                                
                                # Update layout
                                fig3.update_layout(
                                    title=f"12-Month Cost Projection for {appliance}",
                                    xaxis_title="Month",
                                    yaxis_title="Monthly Cost (₹)",
                                    yaxis2=dict(
                                        title="Cumulative Savings (₹)",
                                        overlaying='y',
                                        side='right',
                                    ),
                                    barmode='group',
                                    legend=dict(
                                        orientation="h",
                                        yanchor="bottom",
                                        y=1.02,
                                        xanchor="center",
                                        x=0.5
                                    ),
                                    plot_bgcolor='rgba(0,0,0,0)',
                                    height=400
                                )
                                
                                # Add annotation showing total annual savings
                                fig3.add_annotation(
                                    x=12,
                                    y=cumulative_savings[-1],
                                    text=f"Total Annual Savings: ₹{cumulative_savings[-1]:.2f}",
                                    showarrow=True,
                                    arrowhead=1,
                                    ax=50,
                                    ay=-30,
                                    font=dict(size=14, color="#3498db")
                                )
                                
                                st.plotly_chart(fig3, use_container_width=True, key=f"projected_savings_{appliance}_{idx}")
                                
                                # Add a detailed cost breakdown table
                                st.subheader("Cost Impact Breakdown")
                                
                                # Create a data frame for cost breakdown
                                cost_breakdown = {
                                    "Timeframe": ["Daily", "Monthly", "Yearly", "5 Years"],
                                    "Current Cost": [
                                        rec['current_consumption'] * 8,
                                        rec['current_consumption'] * 8 * 30,
                                        rec['current_consumption'] * 8 * 365,
                                        rec['current_consumption'] * 8 * 365 * 5
                                    ],
                                    "Optimized Cost": [
                                        rec['optimal_consumption'] * 8,
                                        rec['optimal_consumption'] * 8 * 30,
                                        rec['optimal_consumption'] * 8 * 365,
                                        rec['optimal_consumption'] * 8 * 365 * 5
                                    ],
                                    "Savings": [
                                        rec['daily_potential_saving'],
                                        rec['daily_potential_saving'] * 30,
                                        rec['daily_potential_saving'] * 365,
                                        rec['daily_potential_saving'] * 365 * 5
                                    ]
                                }
                                
                                # Convert to DataFrame
                                cost_df = pd.DataFrame(cost_breakdown)
                                
                                # Format the values as currency
                                cost_df["Current Cost"] = cost_df["Current Cost"].apply(lambda x: f"₹{x:.2f}")
                                cost_df["Optimized Cost"] = cost_df["Optimized Cost"].apply(lambda x: f"₹{x:.2f}")
                                cost_df["Savings"] = cost_df["Savings"].apply(lambda x: f"₹{x:.2f}")
                                
                                # Display as a styled table
                                st.table(cost_df)
                                
                                # Add bill comparison visualization
                                st.subheader("Current vs Recommended Bill Comparison")
                                current_bill = rec['current_consumption'] * 8
                                recommended_bill = rec['optimal_consumption'] * 8
                                bill_comparison_fig = create_bill_comparison_chart(current_bill, recommended_bill)
                                st.plotly_chart(bill_comparison_fig, use_container_width=True, key=f"bill_comparison_{appliance}_{idx}")
                                
                                # Add a financial impact visualization for all appliances
                                st.subheader("Total Household Impact")
                                
                                # Calculate household totals from all optimized appliances
                                household_daily_current = sum(r['current_consumption'] * 8 for r in filtered_recommendations)
                                household_daily_optimized = sum(r['optimal_consumption'] * 8 for r in filtered_recommendations)
                                household_daily_saving = household_daily_current - household_daily_optimized
                                
                                household_monthly_current = household_daily_current * 30
                                household_monthly_optimized = household_daily_optimized * 30
                                household_monthly_saving = household_daily_saving * 30
                                
                                household_yearly_current = household_daily_current * 365
                                household_yearly_optimized = household_daily_optimized * 365
                                household_yearly_saving = household_daily_saving * 365
                                
                                # Create a donut chart showing proportion of costs
                                labels = ['Current Cost', 'Cost After Optimization', 'Your Savings']
                                values = [household_yearly_optimized, household_yearly_saving]
                                colors = ['#2ecc71', '#3498db']
                                
                                fig4 = go.Figure(data=[go.Pie(
                                    labels=labels[1:],
                                    values=values,
                                    hole=.5,
                                    marker_colors=colors
                                )])
                                
                                fig4.update_layout(
                                    title="Annual Household Electricity Cost Breakdown",
                                    annotations=[dict(
                                        text=f'₹{household_yearly_saving:.0f}<br>Annual<br>Savings',
                                        x=0.5, y=0.5,
                                        font_size=20,
                                        showarrow=False
                                    )],
                                    plot_bgcolor='rgba(0,0,0,0)',
                                    height=400
                                )
                                
                                total_col1, total_col2 = st.columns([2, 1])
                                
                                with total_col1:
                                    st.plotly_chart(fig4, use_container_width=True, key=f"household_impact_{appliance}_{idx}")
                                
                                with total_col2:
                                    st.subheader("Total Household Savings")
                                
                                # Add household bill comparison
                                st.subheader("Household Bill Comparison")
                                household_bill_comparison = create_bill_comparison_chart(household_daily_current, household_daily_optimized)
                                st.plotly_chart(household_bill_comparison, use_container_width=True, key=f"household_bill_comparison_{appliance}_{idx}")
                                
                                # Define milestone_data before using it
                                milestone_data = []
                                
                                # Create milestone data for savings objectives if there are significant savings
                                if household_monthly_saving > 50:
                                    milestone_data = [
                                        {"Milestone": "New LED Bulbs (₹500)", "Months to Reach": 500 / household_monthly_saving},
                                        {"Milestone": "Smart Power Strip (₹1,500)", "Months to Reach": 1500 / household_monthly_saving},
                                        {"Milestone": "Electricity Bill (₹3,000)", "Months to Reach": 3000 / household_monthly_saving}
                                    ]
                                    # Add more expensive milestones only if savings are substantial
                                    if household_monthly_saving > 200:
                                        milestone_data.append({"Milestone": "Energy Star Fan (₹6,000)", "Months to Reach": 6000 / household_monthly_saving})
                                    if household_monthly_saving > 500:
                                        milestone_data.append({"Milestone": "Efficient Refrigerator (₹20,000)", "Months to Reach": 20000 / household_monthly_saving})
                                
                                # Add milestone visualization with unique key - only if milestone data exists
                                if milestone_data:
                                    milestone_df = pd.DataFrame(milestone_data)
                                    
                                    # Create horizontal bar chart for milestones
                                    fig5 = go.Figure()
                                    fig5.add_trace(go.Bar(
                                        y=milestone_df["Milestone"],
                                        x=milestone_df["Months to Reach"],
                                        orientation='h',
                                        marker_color='#9b59b6',
                                        text=milestone_df["Months to Reach"].apply(lambda x: f"{x:.1f} months"),
                                        textposition='auto'
                                    ))
                                    
                                    fig5.update_layout(
                                        title="How Soon You'll Reach Savings Milestones",
                                        xaxis_title="Months",
                                        yaxis_title="Savings Milestone",
                                        plot_bgcolor='rgba(0,0,0,0)',
                                        height=300
                                    )
                                    
                                    st.plotly_chart(fig5, use_container_width=True, key=f"milestones_{appliance}_{idx}")
                                    
                                    st.info("""
                                    **💰 Savings Reinvestment Tip**: Consider investing your energy savings in energy-efficient 
                                    appliances or home improvements for even greater long-term savings.
                                    """)
                                
                                # Remove any references to figures that might not exist outside of their conditional blocks
                                # (Don't add a reference to fig5 here)
                                
                                # Add long-term upgrade options section - with proper figure definition
                                if rec['current_consumption'] > 1.0:
                                    # Calculate payback period for energy-efficient model
                                    upgrade_cost = 12000  # Approximate cost for energy-efficient model
                                    efficiency_savings = rec['current_consumption'] * 0.3 * 8 * 365  # 30% more efficient
                                    payback_period = upgrade_cost / efficiency_savings
                                    
                                    st.subheader("Long-Term Upgrade Options")
                                    st.write("When you're ready to replace your appliance, consider energy-efficient models:")
                                    
                                    # Create comparison of current vs energy-efficient appliance
                                    current_yearly_cost = rec['current_consumption'] * 8 * 365
                                    efficient_yearly_cost = current_yearly_cost * 0.7  # 30% more efficient
                                    
                                    # Create a simple bar chart comparing current vs efficient model
                                    comparison_data = {
                                        "Model": ["Your Current Appliance", "Energy-Efficient Model"],
                                        "Annual Cost": [current_yearly_cost, efficient_yearly_cost]
                                    }
                                    comparison_df = pd.DataFrame(comparison_data)
                                    
                                    # Define fig6 here before using it
                                    fig6 = go.Figure()
                                    fig6.add_trace(go.Bar(
                                        x=comparison_df["Model"],
                                        y=comparison_df["Annual Cost"],
                                        marker_color=['#e74c3c', '#2ecc71']
                                    ))
                                    
                                    fig6.update_layout(
                                        title=f"Annual Operating Cost Comparison for {appliance}",
                                        yaxis_title="Annual Cost (₹)",
                                        plot_bgcolor='rgba(0,0,0,0)',
                                        height=300
                                    )
                                    
                                    # Add annotations for costs
                                    fig6.add_annotation(
                                        x=0,
                                        y=current_yearly_cost,
                                        text=f"₹{current_yearly_cost:.0f}",
                                        showarrow=False,
                                        yshift=10,
                                        font=dict(color="#ffffff")
                                    )
                                    
                                    fig6.add_annotation(
                                        x=1,
                                        y=efficient_yearly_cost,
                                        text=f"₹{efficient_yearly_cost:.0f}",
                                        showarrow=False,
                                        yshift=10,
                                        font=dict(color="#ffffff")
                                    )
                                    
                                    # Add an annotation for savings
                                    fig6.add_annotation(
                                        x=0.5,
                                        y=efficient_yearly_cost - 2000,
                                        text=f"Save ₹{current_yearly_cost - efficient_yearly_cost:.0f} per year",
                                        showarrow=True,
                                        arrowhead=1,
                                        axref="x",
                                        ayref="y",
                                        ax=1,
                                        ay=efficient_yearly_cost + 1000
                                    )
                                    
                                    upgrade_col1, upgrade_col2 = st.columns([2, 1])
                                    
                                    with upgrade_col1:
                                        # Only display fig6 inside this block where it's defined
                                        st.plotly_chart(fig6, use_container_width=True, key=f"upgrade_comparison_{appliance}_{idx}")
                                    
                                    with upgrade_col2:
                                        st.metric("5-Star Model Cost", f"₹{upgrade_cost:,}", "One-time investment")
                                        st.metric("Annual Savings", f"₹{efficiency_savings:.0f}", f"vs. current model")
                                        st.metric("Payback Period", f"{payback_period:.1f} years", "Break-even time")
                                    
                                    st.info("""
                                    **Note**: While time-shifting provides immediate savings with no investment, upgrading to
                                    energy-efficient models offers additional long-term savings when you're ready to replace
                                    your current appliance.
                                    """)
                                
                                try:
                                    import time
                                    from datetime import datetime
                                    
                                    # Add Q-Learning Visualization Section
                                    st.markdown("### 🤖 AI Learning Process Visualization")
                                    st.markdown("""
                                    <div style='background-color: rgba(52, 152, 219, 0.1); padding: 20px; border-radius: 10px; margin-bottom: 20px;'>
                                        <h4 style='color: #3498db;'>How AI Learns Your Optimal Usage Patterns</h4>
                                        <p>Watch how our Q-Learning algorithm adapts and learns the best times to use your appliances.</p>
                                                    </div>
                                                    """, unsafe_allow_html=True)
                                                    
                                    # Process data for visualization
                                    if 'appliance' in df.columns and 'timestamp' in df.columns and 'consumption_kwh' in df.columns:
                                        # Convert timestamp to datetime if it's not already
                                        if not pd.api.types.is_datetime64_any_dtype(df['timestamp']):
                                            df['timestamp'] = pd.to_datetime(df['timestamp'])
                                        
                                        # Extract hour from timestamp
                                        df['hour'] = df['timestamp'].dt.hour
                                        
                                        # Calculate hourly consumption patterns
                                        hourly_consumption = df.groupby('hour')['consumption_kwh'].mean().reset_index()
                                        
                                        # Initialize Q-Learning agent
                                        q_agent = EnergyQLearningAgent()
                                        
                                        # Create learning visualization data
                                        learning_data = []
                                        rewards_history = []
                                        states_history = []
                                        
                                        # Progress bar for learning process
                                        progress_bar = st.progress(0)
                                        status_text = st.empty()
                                        
                                        # Simulate learning process
                                        episodes = 100
                                        for episode in range(episodes):
                                            total_reward = 0
                                            state_visits = defaultdict(int)
                                            
                                            for hour in range(24):
                                                consumption = hourly_consumption.loc[hourly_consumption['hour'] == hour, 'consumption_kwh'].iloc[0] if hour in hourly_consumption['hour'].values else 0
                                                state = q_agent.get_state(hour, consumption)
                                                action = q_agent.choose_action(state)
                                                
                                                # Calculate reward based on the action and time of day
                                                if hour in peak_hours:
                                                    reward = -10 if action == 'increase' else 5 if action == 'reduce' else 0
                                                elif hour in off_peak_hours:
                                                    reward = 5 if action == 'increase' else -5 if action == 'reduce' else 0
                                                else:
                                                    reward = 2 if action == 'maintain' else -2
                                                    
                                                next_state = q_agent.get_state((hour + 1) % 24, consumption)
                                                q_agent.learn(state, action, reward, next_state)
                                                
                                                total_reward += reward
                                                state_visits[state] += 1
                                            
                                            learning_data.append({
                                                'episode': episode,
                                                'total_reward': total_reward,
                                                'unique_states': len(state_visits)
                                            })
                                            rewards_history.append(total_reward)
                                            states_history.append(len(state_visits))
                                            
                                            # Update progress bar
                                            progress = (episode + 1) / episodes
                                            progress_bar.progress(progress)
                                            status_text.text(f"Learning Episode {episode + 1}/{episodes}")
                                        
                                        # Clear progress indicators
                                        progress_bar.empty()
                                        status_text.empty()
                                        
                                        # Create learning progress visualization
                                        learning_df = pd.DataFrame(learning_data)
                                        
                                        # Plot learning progress
                                        fig_learning = go.Figure()
                                        
                                        # Add rewards trace
                                        fig_learning.add_trace(go.Scatter(
                                            x=learning_df['episode'],
                                            y=learning_df['total_reward'],
                                            name='Total Reward',
                                            mode='lines',
                                            line=dict(color='#2ecc71', width=2)
                                        ))
                                        
                                        # Add states explored trace
                                        fig_learning.add_trace(go.Scatter(
                                            x=learning_df['episode'],
                                            y=learning_df['unique_states'],
                                            name='States Explored',
                                            mode='lines',
                                            line=dict(color='#3498db', width=2),
                                            yaxis='y2'
                                        ))
                                        
                                        fig_learning.update_layout(
                                            title='Q-Learning Progress Over Time',
                                            xaxis_title='Learning Episode',
                                            yaxis_title='Total Reward',
                                            yaxis2=dict(
                                                title='States Explored',
                                                overlaying='y',
                                                side='right'
                                            ),
                                                        plot_bgcolor='rgba(0,0,0,0)',
                                            showlegend=True,
                                            height=400
                                        )
                                        
                                        st.plotly_chart(fig_learning, use_container_width=True)
                                        
                                        # Display learning metrics
                                        col1, col2, col3 = st.columns(3)
                                        
                                        with col1:
                                            st.metric(
                                                "Final Performance",
                                                f"{rewards_history[-1]:.0f}",
                                                "Reward Points"
                                            )
                                        
                                        with col2:
                                            st.metric(
                                                "Best Performance",
                                                f"{max(rewards_history):.0f}",
                                                "Maximum Reward"
                                            )
                                        
                                        with col3:
                                            convergence_episode = rewards_history.index(max(rewards_history))
                                            st.metric(
                                                "Learning Speed",
                                                f"{convergence_episode} episodes",
                                                "Until Best Performance"
                                            )
                                    else:
                                        st.error("Please ensure your CSV file has the required columns: 'timestamp', 'appliance', and 'consumption_kwh'")
                                except Exception as e:
                                    st.error(f"Error in visualization: {str(e)}")
                                    st.info("Please check your data format and try again.")
            except Exception as e:
                st.error(f"Error processing file: {str(e)}")
                st.info("Please ensure your CSV file has the correct format")

# Define a function to simulate the cost of using an appliance at a specific time
def simulate_appliance_cost(appliance_consumption, hour, duration, hourly_rates):
    """Calculate the cost of using an appliance at a specific time for a given duration"""
    total_cost = 0
    for h in range(hour, hour + duration):
        h = h % 24  # Handle wrapping around midnight
        total_cost += appliance_consumption * hourly_rates[h]
    return total_cost

def generate_analysis_pdf(insights, hourly_rates):
    """Generate a PDF report of the electricity consumption analysis"""
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    story = []
    styles = getSampleStyleSheet()
    
    # Custom style for headers
    header_style = ParagraphStyle(
        'CustomHeader',
        parent=styles['Heading1'],
        fontSize=16,
        spaceAfter=20
    )
    
    # Title
    story.append(Paragraph("Electricity Consumption Analysis Report", header_style))
    story.append(Spacer(1, 20))
    
    # Summary Section
    story.append(Paragraph("Summary of Findings", styles['Heading2']))
    story.append(Paragraph(f"Total Daily Savings Potential: ₹{insights['total_potential_saving']:.2f}", styles['Normal']))
    story.append(Paragraph(f"Monthly Savings Projection: ₹{insights['total_potential_saving'] * 30:.2f}", styles['Normal']))
    story.append(Paragraph(f"Yearly Savings Projection: ₹{insights['total_potential_saving'] * 365:.2f}", styles['Normal']))
    story.append(Spacer(1, 20))
    
    # Peak Hour Analysis
    story.append(Paragraph("Peak Hour Analysis", styles['Heading2']))
    peak_usage = insights['hourly_data'].loc[range(18, 22)].sum().sum()
    story.append(Paragraph(f"Peak Hour Usage (6 PM - 10 PM): {peak_usage:.2f} kWh", styles['Normal']))
    story.append(Spacer(1, 20))
    
    # Appliance-wise Analysis
    story.append(Paragraph("Appliance-wise Consumption", styles['Heading2']))
    data = [['Appliance', 'Daily Consumption (kWh)']]
    for appliance, consumption in insights['daily_totals'].items():
        data.append([appliance, f"{consumption:.2f}"])
    
    table = Table(data)
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 14),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
        ('TEXTCOLOR', (0, 1), (-1, -1), colors.black),
        ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 1), (-1, -1), 12),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    story.append(table)
    story.append(Spacer(1, 20))
    
    # Optimization Recommendations
    story.append(Paragraph("Smart Optimization Recommendations", styles['Heading2']))
    for rec in insights['appliance_recommendations']:
        story.append(Paragraph(f"• {rec['appliance']}: {rec['recommendation']}", styles['Normal']))
    story.append(Spacer(1, 20))
    
    # Environmental Impact
    if insights['total_potential_saving'] * 365 > 1000:
        story.append(Paragraph("Environmental Impact", styles['Heading2']))
        kwh_saved = (insights['total_potential_saving'] * 365) / 8
        co2_saved = kwh_saved * 0.82
        trees_equivalent = co2_saved / 20
        story.append(Paragraph(f"Annual CO2 Reduction: {co2_saved:.2f} kg", styles['Normal']))
        story.append(Paragraph(f"Equivalent to planting {trees_equivalent:.1f} trees", styles['Normal']))
    
    # Build PDF
    doc.build(story)
    buffer.seek(0)
    return buffer

class EnergyQLearningAgent:
    def __init__(self):
        self.q_table = {}
        self.learning_rate = 0.1
        self.discount_factor = 0.95
        self.epsilon = 0.1
        self.actions = ['increase', 'reduce', 'maintain']
        
    def get_state(self, hour, consumption):
        """Convert hour and consumption into a discrete state"""
        # Discretize consumption into low, medium, high
        if consumption < 0.5:
            consumption_level = 'low'
        elif consumption < 1.5:
            consumption_level = 'medium'
        else:
            consumption_level = 'high'
            
        # Categorize time of day
        if 6 <= hour < 12:
            time_period = 'morning'
        elif 12 <= hour < 18:
            time_period = 'afternoon'
        elif 18 <= hour < 22:
            time_period = 'evening'
        else:
            time_period = 'night'
            
        return f"{time_period}_{consumption_level}"
        
    def choose_action(self, state):
        """Choose an action using epsilon-greedy policy"""
        if state not in self.q_table:
            self.q_table[state] = {action: 0.0 for action in self.actions}
            
        if np.random.random() < self.epsilon:
            return np.random.choice(self.actions)
        else:
            return max(self.q_table[state].items(), key=lambda x: x[1])[0]
            
    def learn(self, state, action, reward, next_state):
        """Update Q-values using Q-learning algorithm"""
        if state not in self.q_table:
            self.q_table[state] = {action: 0.0 for action in self.actions}
        if next_state not in self.q_table:
            self.q_table[next_state] = {action: 0.0 for action in self.actions}
            
        current_q = self.q_table[state][action]
        next_max_q = max(self.q_table[next_state].values())
        
        # Q-learning update formula
        new_q = current_q + self.learning_rate * (reward + self.discount_factor * next_max_q - current_q)
        self.q_table[state][action] = new_q

if __name__ == "__main__":
    main()
